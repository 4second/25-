#ifndef MOTOR_H
#define MOTOR_H

#include <stdint.h>

void motors_init(void);
void motors_stop(void);
void motors_forward(void);
void motors_forward_speed(uint8_t leftPercent, uint8_t rightPercent);
void motors_turn_left_speed(uint8_t leftPercent, uint8_t rightPercent);
void motors_turn_right_speed(uint8_t leftPercent, uint8_t rightPercent);

#endif
