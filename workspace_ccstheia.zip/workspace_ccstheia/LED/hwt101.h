#ifndef HWT101_H
#define HWT101_H

#include <stdbool.h>
#include <stdint.h>

typedef struct {
    int16_t roll_cdeg;
    int16_t pitch_cdeg;
    int16_t yaw_cdeg;
    bool angle_valid;
} Hwt101Data;

void hwt101_init(void);
void hwt101_update(void);
bool hwt101_get_data(Hwt101Data *data);
bool hwt101_get_yaw_cdeg(int16_t *yaw_cdeg);

#endif
