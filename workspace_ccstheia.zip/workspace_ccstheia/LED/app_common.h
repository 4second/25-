#ifndef APP_COMMON_H
#define APP_COMMON_H

#include <stdbool.h>
#include <stdint.h>

#define LINE_SENSOR_ALL_WHITE_DATA       ((uint8_t) 0U)
#define LINE_SENSOR_ALL_BLACK_DATA       ((uint8_t) 0xFFU)

#define APP_BUZZER_BEEP_MS               (180U)
#define APP_BUTTON_DEBOUNCE_MS           (20U)

#define MOTOR_LEFT_BASE_SPEED            (33U)
#define MOTOR_RIGHT_BASE_SPEED           (34U)
#define MOTOR_SLIGHT_LEFT_SPEED          (28U)
#define MOTOR_SLIGHT_RIGHT_SPEED         (28U)
#define MOTOR_HARD_SLOW_SPEED            (18U)
#define MOTOR_SLIGHT_FAST_SPEED          (34U)
#define MOTOR_HARD_FAST_SPEED            (35U)
#define MOTOR_TURN_SPEED                 (16U)
#define MOTOR_ALIGN_TURN_SPEED           (15U)
#define MOTOR_CORNER_INNER_SPEED         (18U)
#define MOTOR_CORNER_OUTER_SPEED         (27U)
#define MOTOR_STABLE_LEFT_BASE_SPEED     (24U)
#define MOTOR_STABLE_RIGHT_BASE_SPEED    (26U)
#define MOTOR_STABLE_SLOW_SPEED          (17U)
#define MOTOR_STABLE_FAST_SPEED          (27U)
#define MOTOR_RECOVER_SLOW_SPEED         (13U)
#define MOTOR_RECOVER_FAST_SPEED         (24U)
#define MOTOR_CENTER_NUDGE_SLOW_SPEED    (21U)
#define MOTOR_CENTER_NUDGE_FAST_SPEED    (23U)
#define MOTOR_D_REACQUIRE_SLOW_SPEED     (16U)
#define MOTOR_D_REACQUIRE_FAST_SPEED     (22U)
#define MOTOR_GAP_BASE_SPEED             (31U)
#define MOTOR_WHITE_RECOVER_SPEED        (15U)

#define LINE_ERROR_HARD_LEFT_THRESHOLD   (-5)
#define LINE_ERROR_SLIGHT_LEFT_THRESHOLD (-2)
#define LINE_ERROR_SLIGHT_RIGHT_THRESHOLD (2)
#define LINE_ERROR_HARD_RIGHT_THRESHOLD  (5)

#define LINE_SENSOR_CENTER_MASK          ((uint8_t) ((1U << 3) | (1U << 4)))
#define LINE_SENSOR_LEFT_EDGE_MASK       ((uint8_t) (1U << 0))
#define LINE_SENSOR_RIGHT_EDGE_MASK      ((uint8_t) (1U << 7))
#define LINE_SENSOR_LEFT_GAP_MASK        ((uint8_t) (1U << 2))
#define LINE_SENSOR_RIGHT_GAP_MASK       ((uint8_t) (1U << 5))
#define LINE_SENSOR_LEFT_BRANCH_MASK     ((uint8_t) ((1U << 0) | (1U << 1) | (1U << 2)))
#define LINE_SENSOR_RIGHT_BRANCH_MASK    ((uint8_t) ((1U << 5) | (1U << 6) | (1U << 7)))
#define LINE_SENSOR_LEFT_RECOVER_MASK    ((uint8_t) ((1U << 0) | (1U << 1)))
#define LINE_SENSOR_RIGHT_RECOVER_MASK   ((uint8_t) ((1U << 6) | (1U << 7)))
#define LINE_SENSOR_START_TURN_MIN_COUNT  (80U)
#define LINE_SENSOR_RETURN_CORNER_MIN_COUNT (80U)
#define LINE_SENSOR_CORNER_TRIGGER_COUNT  (2U)
#define LINE_SENSOR_BRANCH_STOP_COUNT     (20U)
#define LINE_SENSOR_C_MIN_LOOP_COUNT      (260U)
#define LINE_SENSOR_WHITE_STOP_COUNT      (14U)
#define LINE_SENSOR_TRANSIENT_INVALID_HOLD_COUNT (2U)
#define LINE_SENSOR_TURN_AROUND_MIN_COUNT (55U)
#define LINE_SENSOR_TURN_AROUND_MAX_COUNT (500U)
#define LINE_SENSOR_ALIGN_MAX_COUNT       (240U)
#define LINE_SENSOR_ALIGN_CENTER_COUNT    (30U)
#define LINE_SENSOR_STABLE_COUNT          (160U)
#define LINE_SENSOR_STABLE_CENTER_COUNT   (35U)
#define LINE_SENSOR_POST_CORNER_STABLE_COUNT (140U)
#define LINE_SENSOR_POST_CORNER_CENTER_COUNT (25U)
#define LINE_SENSOR_CORNER_MIN_COUNT      (18U)
#define LINE_SENSOR_CORNER_CENTER_COUNT   (2U)
#define LINE_SENSOR_CORNER_MAX_COUNT      (120U)
#define LINE_SENSOR_A_MIN_LOOP_COUNT      (350U)
#define LINE_SENSOR_A_MAX_LOOP_COUNT      (2000U)
#define LINE_SENSOR_A_BLACK_MIN_COUNT     (5U)
#define LINE_SENSOR_A_STOP_COUNT          (16U)
#define LINE_SENSOR_FINAL_WHITE_STOP_COUNT (60U)
#define LINE_SENSOR_TURN_LOST_MIN_COUNT   (12U)
#define LINE_SENSOR_CENTER_MAX_BLACK_COUNT (4U)
#define LINE_SENSOR_TURN_CENTER_MAX_BLACK_COUNT (5U)

#define GYRO_YAW_HALF_WRAP_CDEG        (18000)
#define GYRO_YAW_FULL_WRAP_CDEG        (36000)
#define LINE_STRAIGHT_KP_GAIN          (1)
#define LINE_STRAIGHT_KD_GAIN          (0)
#define LINE_STRAIGHT_MAX_CORRECTION   (3)

#define GYRO_STRAIGHT_KP_DIVISOR       (420)
#define GYRO_STRAIGHT_MAX_CORRECTION   (1)
#define GYRO_GAP_KP_DIVISOR            (160)
#define GYRO_GAP_MAX_CORRECTION        (8)
#define GYRO_LINE_PRIMARY_MAX_ERROR     (2)

#define MODE2_GAP_MIN_LOOP_COUNT        (45U)
#define MODE2_D_CENTER_COUNT            (28U)
#define MODE2_E_MIN_LOOP_COUNT          (130U)
#define MODE2_E_STOP_COUNT              (8U)

#define MODE3_E_TURN_MIN_LOOP_COUNT     LINE_SENSOR_RETURN_CORNER_MIN_COUNT
#define MODE3_F_MIN_LOOP_COUNT          LINE_SENSOR_C_MIN_LOOP_COUNT
#define MODE3_F_WHITE_STOP_COUNT        LINE_SENSOR_WHITE_STOP_COUNT
#define MODE3_RETURN_D_MIN_LOOP_COUNT   (120U)
#define MODE3_RETURN_GAP_CENTER_COUNT   (60U)
#define MODE3_RETURN_REACQUIRE_CENTER_COUNT (45U)

typedef enum {
    MODE_RESULT_DONE,
    MODE_RESULT_SWITCH_TO_MODE2,
    MODE_RESULT_SWITCH_TO_MODE3
} ModeResult;

typedef enum {
    LINE_SIDE_LEFT,
    LINE_SIDE_RIGHT
} LineSide;

typedef enum {
    CORNER_STATE_NONE,
    CORNER_STATE_RIGHT,
    CORNER_STATE_LEFT
} CornerState;

uint8_t line_sensor_count_black(uint8_t data);
bool line_sensor_centered(uint8_t data);
bool line_sensor_all_white_or_black(uint8_t data);
bool line_sensor_detect_right_corner(uint8_t data);
bool line_sensor_detect_left_corner(uint8_t data);
bool line_sensor_reacquired_center(uint8_t data);

void car_follow_corner(CornerState cornerState);
void car_hold_turn_direction(LineSide lastLineSide);
void car_follow_transient_white(LineSide lastLineSide);
void car_turn_to_center_line(uint8_t lineSensorData, LineSide preferredSide);
void mode2_turn_to_center_line(uint8_t lineSensorData, LineSide *lastLineSide);
void mode3_reacquire_line_on_45(uint8_t lineSensorData, LineSide *lastLineSide);
void car_center_line_on_45(uint8_t lineSensorData, LineSide *lastLineSide);
void car_follow_line_stable(uint8_t lineSensorData, LineSide *lastLineSide);
void car_follow_gap_gyro(int16_t targetYaw, int16_t currentYaw, bool gyroControlEnabled);

void app_buzzer_beep(void);
void app_buzzer_beep_times(uint8_t count);
bool app_button_pressed(void);
bool app_button_take_press(void);
void app_wait_button_press(void);

#endif
