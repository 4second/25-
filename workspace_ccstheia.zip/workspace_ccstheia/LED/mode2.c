#include "mode2.h"

#include "app_common.h"
#include "delay.h"
#include "hwt101.h"
#include "line_sensor.h"
#include "motor.h"

typedef enum {
    MODE2_STATE_START_ALIGN_AB,
    MODE2_STATE_GO_FIRST_LINE,
    MODE2_STATE_PREPARE_FIRST_TURN,
    MODE2_STATE_TURN_TO_EDGE_8,
    MODE2_STATE_ALIGN_AFTER_FIRST_TURN,
    MODE2_STATE_GO_TO_C,
    MODE2_STATE_CROSS_GAP_GYRO,
    MODE2_STATE_ALIGN_AFTER_REACQUIRE_D,
    MODE2_STATE_GO_TO_E,
    MODE2_STATE_STOPPED
} Mode2State;

ModeResult mode2_run(void)
{
    uint8_t lineSensorData = LINE_SENSOR_ALL_WHITE_DATA;
    uint16_t stateLoopCount = 0;
    uint16_t whiteLoopCount = 0;
    uint8_t rightCornerDetectCount = 0;
    uint8_t centerStableCount = 0;
    uint8_t eDetectCount = 0;
    int16_t currentYaw = 0;
    int16_t gapTargetYaw = 0;
    bool gyroValid = false;
    bool gapYawCaptured = false;
    bool lineRead = false;
    bool turnCenterLost = false;
    Mode2State mode2State = MODE2_STATE_START_ALIGN_AB;
    LineSide lastLineSide = LINE_SIDE_RIGHT;

    while (1) {
        hwt101_update();
        gyroValid = hwt101_get_yaw_cdeg(&currentYaw);

        if (app_button_pressed()) {
            motors_stop();
            (void) app_button_take_press();
            return MODE_RESULT_SWITCH_TO_MODE3;
        }

        if (mode2State == MODE2_STATE_STOPPED) {
            motors_stop();
            return MODE_RESULT_DONE;
        }

        lineRead = line_sensor_read(&lineSensorData);
        if (!lineRead) {
            if (mode2State == MODE2_STATE_CROSS_GAP_GYRO) {
                car_follow_gap_gyro(gapTargetYaw, currentYaw, gyroValid && gapYawCaptured);
            } else if (mode2State == MODE2_STATE_TURN_TO_EDGE_8) {
                stateLoopCount++;
                car_follow_corner(CORNER_STATE_RIGHT);
                lastLineSide = LINE_SIDE_RIGHT;
                if (stateLoopCount >= LINE_SENSOR_CORNER_MAX_COUNT) {
                    mode2State = MODE2_STATE_ALIGN_AFTER_FIRST_TURN;
                    stateLoopCount = 0;
                    centerStableCount = 0;
                    whiteLoopCount = 0;
                }
            } else {
                motors_stop();
            }
            delay_ms(5);
            continue;
        }

        switch (mode2State) {
        case MODE2_STATE_START_ALIGN_AB:
            stateLoopCount++;
            if (lineSensorData == LINE_SENSOR_ALL_WHITE_DATA) {
                centerStableCount = 0;
                car_follow_transient_white(lastLineSide);
            } else {
                car_follow_line_stable(lineSensorData, &lastLineSide);
                if (line_sensor_reacquired_center(lineSensorData)) {
                    centerStableCount++;
                } else {
                    centerStableCount = 0;
                }
            }

            if (centerStableCount >= LINE_SENSOR_STABLE_CENTER_COUNT) {
                mode2State = MODE2_STATE_GO_FIRST_LINE;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                rightCornerDetectCount = 0;
            }
            break;

        case MODE2_STATE_GO_FIRST_LINE:
            stateLoopCount++;
            if ((stateLoopCount >= LINE_SENSOR_START_TURN_MIN_COUNT) &&
                line_sensor_detect_right_corner(lineSensorData)) {
                rightCornerDetectCount++;
            } else {
                rightCornerDetectCount = 0;
            }

            if (rightCornerDetectCount >= LINE_SENSOR_CORNER_TRIGGER_COUNT) {
                mode2State = MODE2_STATE_PREPARE_FIRST_TURN;
                stateLoopCount = 0;
                rightCornerDetectCount = 0;
                whiteLoopCount = 0;
                centerStableCount = 0;
                motors_stop();
            } else {
                if (lineSensorData != LINE_SENSOR_ALL_WHITE_DATA) {
                    car_follow_line_stable(lineSensorData, &lastLineSide);
                } else {
                    car_follow_transient_white(lastLineSide);
                }
            }
            break;

        case MODE2_STATE_PREPARE_FIRST_TURN:
            stateLoopCount++;
            motors_stop();

            if (stateLoopCount >= LINE_SENSOR_BRANCH_STOP_COUNT) {
                mode2State = MODE2_STATE_TURN_TO_EDGE_8;
                stateLoopCount = 0;
                centerStableCount = 0;
                turnCenterLost = false;
                lastLineSide = LINE_SIDE_RIGHT;
            }
            break;

        case MODE2_STATE_TURN_TO_EDGE_8:
            stateLoopCount++;
            car_follow_corner(CORNER_STATE_RIGHT);
            lastLineSide = LINE_SIDE_RIGHT;

            if ((stateLoopCount >= LINE_SENSOR_TURN_LOST_MIN_COUNT) &&
                !line_sensor_centered(lineSensorData)) {
                turnCenterLost = true;
            }

            if (!turnCenterLost || (stateLoopCount < LINE_SENSOR_CORNER_MIN_COUNT)) {
                centerStableCount = 0;
            } else if (line_sensor_reacquired_center(lineSensorData)) {
                centerStableCount++;
            } else {
                centerStableCount = 0;
            }

            if (centerStableCount >= LINE_SENSOR_CORNER_CENTER_COUNT) {
                mode2State = MODE2_STATE_ALIGN_AFTER_FIRST_TURN;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                lastLineSide = LINE_SIDE_RIGHT;
            } else if (stateLoopCount >= LINE_SENSOR_CORNER_MAX_COUNT) {
                mode2State = MODE2_STATE_ALIGN_AFTER_FIRST_TURN;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
            }
            break;

        case MODE2_STATE_ALIGN_AFTER_FIRST_TURN:
            stateLoopCount++;
            if (line_sensor_all_white_or_black(lineSensorData)) {
                whiteLoopCount++;
                centerStableCount = 0;
                car_hold_turn_direction(LINE_SIDE_RIGHT);
                if (whiteLoopCount <= LINE_SENSOR_TRANSIENT_INVALID_HOLD_COUNT) {
                    delay_ms(2U);
                }
            } else if (!line_sensor_centered(lineSensorData)) {
                whiteLoopCount = 0;
                centerStableCount = 0;
                car_turn_to_center_line(lineSensorData, LINE_SIDE_RIGHT);
            } else {
                whiteLoopCount = 0;
                centerStableCount++;
                car_follow_line_stable(lineSensorData, &lastLineSide);
            }

            if ((stateLoopCount >= LINE_SENSOR_STABLE_COUNT) &&
                (centerStableCount >= LINE_SENSOR_STABLE_CENTER_COUNT)) {
                mode2State = MODE2_STATE_GO_TO_C;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                gapYawCaptured = false;
            }
            break;

        case MODE2_STATE_GO_TO_C:
            stateLoopCount++;
            if (lineSensorData == LINE_SENSOR_ALL_WHITE_DATA) {
                if (stateLoopCount >= LINE_SENSOR_C_MIN_LOOP_COUNT) {
                    whiteLoopCount++;
                    car_follow_transient_white(lastLineSide);
                    if (whiteLoopCount >= LINE_SENSOR_WHITE_STOP_COUNT) {
                        if (!gapYawCaptured && gyroValid) {
                            gapTargetYaw = currentYaw;
                            gapYawCaptured = true;
                        }
                        mode2State = MODE2_STATE_CROSS_GAP_GYRO;
                        stateLoopCount = 0;
                        centerStableCount = 0;
                        whiteLoopCount = 0;
                    }
                } else {
                    whiteLoopCount = 0;
                    car_follow_transient_white(lastLineSide);
                }
            } else {
                whiteLoopCount = 0;
                if (!line_sensor_centered(lineSensorData)) {
                    centerStableCount = 0;
                    car_center_line_on_45(lineSensorData, &lastLineSide);
                } else {
                    centerStableCount++;
                    if (gyroValid) {
                        gapTargetYaw = currentYaw;
                        gapYawCaptured = true;
                    }
                    car_follow_line_stable(lineSensorData, &lastLineSide);
                }
            }
            break;

        case MODE2_STATE_CROSS_GAP_GYRO:
            stateLoopCount++;
            car_follow_gap_gyro(gapTargetYaw, currentYaw, gyroValid && gapYawCaptured);

            if ((stateLoopCount >= MODE2_GAP_MIN_LOOP_COUNT) &&
                (lineSensorData != LINE_SENSOR_ALL_WHITE_DATA) &&
                (lineSensorData != LINE_SENSOR_ALL_BLACK_DATA)) {
                mode2State = MODE2_STATE_ALIGN_AFTER_REACQUIRE_D;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                lastLineSide = LINE_SIDE_RIGHT;
            }
            break;

        case MODE2_STATE_ALIGN_AFTER_REACQUIRE_D:
            stateLoopCount++;
            if (!line_sensor_centered(lineSensorData)) {
                centerStableCount = 0;
                mode2_turn_to_center_line(lineSensorData, &lastLineSide);
            } else {
                centerStableCount++;
                car_follow_line_stable(lineSensorData, &lastLineSide);
            }

            if (centerStableCount >= MODE2_D_CENTER_COUNT) {
                mode2State = MODE2_STATE_GO_TO_E;
                stateLoopCount = 0;
                centerStableCount = 0;
                eDetectCount = 0;
            }
            break;

        case MODE2_STATE_GO_TO_E:
            stateLoopCount++;
            if ((stateLoopCount >= MODE2_E_MIN_LOOP_COUNT) &&
                ((lineSensorData & LINE_SENSOR_CENTER_MASK) != 0U) &&
                ((lineSensorData & LINE_SENSOR_LEFT_BRANCH_MASK) != 0U)) {
                eDetectCount++;
                if (eDetectCount >= MODE2_E_STOP_COUNT) {
                    mode2State = MODE2_STATE_STOPPED;
                    motors_stop();
                }
            } else {
                eDetectCount = 0;
            }

            if (mode2State != MODE2_STATE_STOPPED) {
                if (lineSensorData != LINE_SENSOR_ALL_WHITE_DATA) {
                    car_follow_line_stable(lineSensorData, &lastLineSide);
                } else {
                    car_follow_transient_white(lastLineSide);
                }
            }
            break;

        case MODE2_STATE_STOPPED:
        default:
            mode2State = MODE2_STATE_STOPPED;
            motors_stop();
            break;
        }

        delay_ms(5);
    }
}

