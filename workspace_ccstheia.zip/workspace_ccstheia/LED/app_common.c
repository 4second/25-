#include "app_common.h"

#include "delay.h"
#include "line_sensor.h"
#include "motor.h"
#include "ti_msp_dl_config.h"

static int8_t line_sensor_get_error(uint8_t data)
{
    int8_t error = 0;
    uint8_t count = 0;

    if ((data & (1U << 0)) != 0U) {
        error -= 4;
        count++;
    }
    if ((data & (1U << 1)) != 0U) {
        error -= 3;
        count++;
    }
    if ((data & (1U << 2)) != 0U) {
        error -= 2;
        count++;
    }
    if ((data & (1U << 3)) != 0U) {
        error -= 1;
        count++;
    }
    if ((data & (1U << 4)) != 0U) {
        error += 1;
        count++;
    }
    if ((data & (1U << 5)) != 0U) {
        error += 2;
        count++;
    }
    if ((data & (1U << 6)) != 0U) {
        error += 3;
        count++;
    }
    if ((data & (1U << 7)) != 0U) {
        error += 4;
        count++;
    }

    if (count == 0U) {
        return 0;
    }

    return (int8_t) (error / (int8_t) count);
}

static int16_t car_yaw_error_cdeg(int16_t targetYaw, int16_t currentYaw)
{
    int32_t error = (int32_t) targetYaw - (int32_t) currentYaw;

    if (error > GYRO_YAW_HALF_WRAP_CDEG) {
        error -= GYRO_YAW_FULL_WRAP_CDEG;
    } else if (error < -GYRO_YAW_HALF_WRAP_CDEG) {
        error += GYRO_YAW_FULL_WRAP_CDEG;
    }

    return (int16_t) error;
}

static int16_t car_limit_correction_range(int16_t correction, int16_t maxCorrection)
{
    if (correction > maxCorrection) {
        return maxCorrection;
    }
    if (correction < -maxCorrection) {
        return (int16_t) -maxCorrection;
    }

    return correction;
}

static uint8_t car_clamp_speed(int16_t speed)
{
    if (speed < 0) {
        return 0U;
    }
    if (speed > 100) {
        return 100U;
    }

    return (uint8_t) speed;
}

uint8_t line_sensor_count_black(uint8_t data)
{
    uint8_t count = 0;

    for (uint8_t mask = 1U; mask != 0U; mask <<= 1) {
        if ((data & mask) != 0U) {
            count++;
        }
    }

    return count;
}

bool line_sensor_centered(uint8_t data)
{
    int8_t error = line_sensor_get_error(data);

    return ((data & LINE_SENSOR_CENTER_MASK) != 0U) &&
        (line_sensor_count_black(data) <= LINE_SENSOR_CENTER_MAX_BLACK_COUNT) &&
        (error >= -1) && (error <= 1);
}

bool line_sensor_all_white_or_black(uint8_t data)
{
    return (data == LINE_SENSOR_ALL_WHITE_DATA) || (data == LINE_SENSOR_ALL_BLACK_DATA);
}

bool line_sensor_detect_right_corner(uint8_t data)
{
    uint8_t rightBranchCount = line_sensor_count_black((uint8_t) (data & LINE_SENSOR_RIGHT_BRANCH_MASK));

    return (data != LINE_SENSOR_ALL_BLACK_DATA) &&
        (((data & LINE_SENSOR_RIGHT_EDGE_MASK) != 0U) ||
            (rightBranchCount >= 2U)) &&
        (((data & LINE_SENSOR_CENTER_MASK) != 0U) ||
            ((data & ((1U << 4) | (1U << 5) | (1U << 6))) != 0U));
}

bool line_sensor_detect_left_corner(uint8_t data)
{
    return (data != LINE_SENSOR_ALL_BLACK_DATA) &&
        (((data & LINE_SENSOR_LEFT_EDGE_MASK) != 0U) ||
            (line_sensor_count_black((uint8_t) (data & LINE_SENSOR_LEFT_BRANCH_MASK)) >= 2U)) &&
        ((data & ((1U << 1) | (1U << 2) | (1U << 3))) != 0U);
}

bool line_sensor_reacquired_center(uint8_t data)
{
    uint8_t blackCount = line_sensor_count_black(data);
    uint8_t innerMask = (uint8_t) ((1U << 2) | (1U << 3) | (1U << 4) | (1U << 5));
    bool leftOuterWhite = ((data & ((1U << 0) | (1U << 1))) == 0U);
    bool rightOuterWhite = ((data & ((1U << 6) | (1U << 7))) == 0U);

    return (data != LINE_SENSOR_ALL_BLACK_DATA) &&
        ((data & LINE_SENSOR_CENTER_MASK) != 0U) &&
        ((data & innerMask) != 0U) &&
        (leftOuterWhite || rightOuterWhite) &&
        (blackCount > 0U) &&
        (blackCount <= LINE_SENSOR_TURN_CENTER_MAX_BLACK_COUNT);
}

void car_follow_corner(CornerState cornerState)
{
    if (cornerState == CORNER_STATE_RIGHT) {
        motors_turn_right_speed(MOTOR_CORNER_OUTER_SPEED, MOTOR_CORNER_INNER_SPEED);
    } else {
        motors_turn_left_speed(MOTOR_CORNER_INNER_SPEED, MOTOR_CORNER_OUTER_SPEED);
    }
}

void car_hold_turn_direction(LineSide lastLineSide)
{
    if (lastLineSide == LINE_SIDE_LEFT) {
        motors_turn_left_speed(MOTOR_ALIGN_TURN_SPEED, MOTOR_ALIGN_TURN_SPEED);
    } else {
        motors_turn_right_speed(MOTOR_ALIGN_TURN_SPEED, MOTOR_ALIGN_TURN_SPEED);
    }
}

void car_follow_transient_white(LineSide lastLineSide)
{
    if (lastLineSide == LINE_SIDE_LEFT) {
        motors_forward_speed(MOTOR_RECOVER_SLOW_SPEED, MOTOR_RECOVER_FAST_SPEED);
    } else {
        motors_forward_speed(MOTOR_RECOVER_FAST_SPEED, MOTOR_RECOVER_SLOW_SPEED);
    }
}

void car_turn_to_center_line(uint8_t lineSensorData, LineSide preferredSide)
{
    int8_t lineError;

    if ((lineSensorData == LINE_SENSOR_ALL_WHITE_DATA) ||
        (lineSensorData == LINE_SENSOR_ALL_BLACK_DATA)) {
        car_hold_turn_direction(preferredSide);
        return;
    }

    lineError = line_sensor_get_error(lineSensorData);
    if (lineError <= LINE_ERROR_SLIGHT_LEFT_THRESHOLD) {
        motors_turn_left_speed(MOTOR_ALIGN_TURN_SPEED, MOTOR_ALIGN_TURN_SPEED);
    } else if (lineError >= LINE_ERROR_SLIGHT_RIGHT_THRESHOLD) {
        motors_turn_right_speed(MOTOR_ALIGN_TURN_SPEED, MOTOR_ALIGN_TURN_SPEED);
    } else {
        motors_forward_speed(0U, 0U);
    }
}

void mode2_turn_to_center_line(uint8_t lineSensorData, LineSide *lastLineSide)
{
    int8_t lineError;

    if (lineSensorData == LINE_SENSOR_ALL_WHITE_DATA) {
        car_follow_transient_white(*lastLineSide);
        return;
    }
    if (lineSensorData == LINE_SENSOR_ALL_BLACK_DATA) {
        motors_forward_speed(MOTOR_D_REACQUIRE_SLOW_SPEED, MOTOR_D_REACQUIRE_FAST_SPEED);
        return;
    }

    lineError = line_sensor_get_error(lineSensorData);
    if ((lineSensorData & LINE_SENSOR_CENTER_MASK) != 0U) {
        car_follow_line_stable(lineSensorData, lastLineSide);
    } else if (lineError < 0) {
        *lastLineSide = LINE_SIDE_LEFT;
        motors_forward_speed(MOTOR_D_REACQUIRE_SLOW_SPEED, MOTOR_D_REACQUIRE_FAST_SPEED);
    } else if (lineError > 0) {
        *lastLineSide = LINE_SIDE_RIGHT;
        motors_forward_speed(MOTOR_D_REACQUIRE_FAST_SPEED, MOTOR_D_REACQUIRE_SLOW_SPEED);
    } else {
        motors_forward_speed(MOTOR_D_REACQUIRE_SLOW_SPEED, MOTOR_D_REACQUIRE_FAST_SPEED);
    }
}

void mode3_reacquire_line_on_45(uint8_t lineSensorData, LineSide *lastLineSide)
{
    if (lineSensorData == LINE_SENSOR_ALL_WHITE_DATA) {
        car_follow_transient_white(*lastLineSide);
        return;
    }
    if (lineSensorData == LINE_SENSOR_ALL_BLACK_DATA) {
        motors_forward_speed(MOTOR_D_REACQUIRE_SLOW_SPEED, MOTOR_D_REACQUIRE_FAST_SPEED);
        return;
    }

    if (line_sensor_centered(lineSensorData)) {
        car_follow_line_stable(lineSensorData, lastLineSide);
    } else if ((lineSensorData & LINE_SENSOR_CENTER_MASK) != 0U) {
        car_center_line_on_45(lineSensorData, lastLineSide);
    } else {
        mode2_turn_to_center_line(lineSensorData, lastLineSide);
    }
}

void car_center_line_on_45(uint8_t lineSensorData, LineSide *lastLineSide)
{
    int8_t lineError;

    if (lineSensorData == LINE_SENSOR_ALL_WHITE_DATA) {
        car_follow_transient_white(*lastLineSide);
        return;
    }
    if (lineSensorData == LINE_SENSOR_ALL_BLACK_DATA) {
        motors_forward_speed(MOTOR_CENTER_NUDGE_SLOW_SPEED, MOTOR_CENTER_NUDGE_FAST_SPEED);
        return;
    }

    lineError = line_sensor_get_error(lineSensorData);
    if (!line_sensor_centered(lineSensorData)) {
        if (lineError < 0) {
            *lastLineSide = LINE_SIDE_LEFT;
            motors_turn_left_speed(MOTOR_ALIGN_TURN_SPEED, MOTOR_ALIGN_TURN_SPEED);
        } else if (lineError > 0) {
            *lastLineSide = LINE_SIDE_RIGHT;
            motors_turn_right_speed(MOTOR_ALIGN_TURN_SPEED, MOTOR_ALIGN_TURN_SPEED);
        } else {
            motors_forward_speed(MOTOR_CENTER_NUDGE_SLOW_SPEED, MOTOR_CENTER_NUDGE_FAST_SPEED);
        }
        return;
    }

    car_follow_line_stable(lineSensorData, lastLineSide);
}

void car_follow_line_stable(uint8_t lineSensorData, LineSide *lastLineSide)
{
    int8_t lineError;

    lineError = line_sensor_get_error(lineSensorData);

    if (((lineSensorData & LINE_SENSOR_CENTER_MASK) == 0U) &&
        ((lineSensorData & LINE_SENSOR_LEFT_RECOVER_MASK) != 0U)) {
        *lastLineSide = LINE_SIDE_LEFT;
        motors_forward_speed(MOTOR_RECOVER_SLOW_SPEED, MOTOR_RECOVER_FAST_SPEED);
    } else if (((lineSensorData & LINE_SENSOR_CENTER_MASK) == 0U) &&
        ((lineSensorData & LINE_SENSOR_RIGHT_RECOVER_MASK) != 0U)) {
        *lastLineSide = LINE_SIDE_RIGHT;
        motors_forward_speed(MOTOR_RECOVER_FAST_SPEED, MOTOR_RECOVER_SLOW_SPEED);
    } else if (lineError <= LINE_ERROR_HARD_LEFT_THRESHOLD) {
        *lastLineSide = LINE_SIDE_LEFT;
        motors_forward_speed(MOTOR_STABLE_SLOW_SPEED, MOTOR_STABLE_FAST_SPEED);
    } else if (lineError <= LINE_ERROR_SLIGHT_LEFT_THRESHOLD) {
        *lastLineSide = LINE_SIDE_LEFT;
        motors_forward_speed(MOTOR_STABLE_SLOW_SPEED, MOTOR_STABLE_FAST_SPEED);
    } else if (lineError >= LINE_ERROR_HARD_RIGHT_THRESHOLD) {
        *lastLineSide = LINE_SIDE_RIGHT;
        motors_forward_speed(MOTOR_STABLE_FAST_SPEED, MOTOR_STABLE_SLOW_SPEED);
    } else if (lineError >= LINE_ERROR_SLIGHT_RIGHT_THRESHOLD) {
        *lastLineSide = LINE_SIDE_RIGHT;
        motors_forward_speed(MOTOR_STABLE_FAST_SPEED, MOTOR_STABLE_SLOW_SPEED);
    } else if (((lineSensorData & LINE_SENSOR_CENTER_MASK) != 0U) && (lineError < 0)) {
        *lastLineSide = LINE_SIDE_LEFT;
        motors_forward_speed(MOTOR_CENTER_NUDGE_SLOW_SPEED, MOTOR_CENTER_NUDGE_FAST_SPEED);
    } else if (((lineSensorData & LINE_SENSOR_CENTER_MASK) != 0U) && (lineError > 0)) {
        *lastLineSide = LINE_SIDE_RIGHT;
        motors_forward_speed(MOTOR_CENTER_NUDGE_FAST_SPEED, MOTOR_CENTER_NUDGE_SLOW_SPEED);
    } else {
        motors_forward_speed(MOTOR_STABLE_LEFT_BASE_SPEED, MOTOR_STABLE_RIGHT_BASE_SPEED);
    }
}

void app_buzzer_beep(void)
{
    DL_GPIO_setPins(buzzer_PORT, buzzer_PIN_4_PIN);
    delay_ms(APP_BUZZER_BEEP_MS);
    DL_GPIO_clearPins(buzzer_PORT, buzzer_PIN_4_PIN);
    delay_ms(APP_BUZZER_BEEP_MS);
}

void app_buzzer_beep_times(uint8_t count)
{
    while (count > 0U) {
        app_buzzer_beep();
        count--;
    }
}

bool app_button_pressed(void)
{
    return (DL_GPIO_readPins(key_PORT, key_PIN_5_PIN) == 0U);
}

bool app_button_take_press(void)
{
    if (!app_button_pressed()) {
        return false;
    }

    delay_ms(APP_BUTTON_DEBOUNCE_MS);
    if (!app_button_pressed()) {
        return false;
    }

    while (app_button_pressed()) {
        delay_ms(5U);
    }
    delay_ms(APP_BUTTON_DEBOUNCE_MS);

    return true;
}

void app_wait_button_press(void)
{
    while (1) {
        motors_stop();
        if (app_button_take_press()) {
            return;
        }
        delay_ms(5U);
    }
}

void car_follow_gap_gyro(int16_t targetYaw, int16_t currentYaw, bool gyroControlEnabled)
{
    int16_t gyroCorrection = 0;
    int16_t leftSpeed = MOTOR_GAP_BASE_SPEED;
    int16_t rightSpeed = MOTOR_GAP_BASE_SPEED;

    if (gyroControlEnabled) {
        gyroCorrection = car_limit_correction_range(
            car_yaw_error_cdeg(targetYaw, currentYaw) / GYRO_GAP_KP_DIVISOR,
            GYRO_GAP_MAX_CORRECTION);
        leftSpeed += gyroCorrection;
        rightSpeed -= gyroCorrection;
    }

    motors_forward_speed(car_clamp_speed(leftSpeed), car_clamp_speed(rightSpeed));
}
