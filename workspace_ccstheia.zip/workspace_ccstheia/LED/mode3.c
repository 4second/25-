#include "mode3.h"

#include "app_common.h"
#include "delay.h"
#include "hwt101.h"
#include "line_sensor.h"
#include "motor.h"

typedef enum {
    MODE3_STATE_START_ALIGN_AB,
    MODE3_STATE_GO_FIRST_LINE,
    MODE3_STATE_PREPARE_FIRST_TURN,
    MODE3_STATE_TURN_TO_EDGE_8,
    MODE3_STATE_ALIGN_AFTER_FIRST_TURN,
    MODE3_STATE_GO_TO_C,
    MODE3_STATE_CROSS_GAP_TO_D,
    MODE3_STATE_ALIGN_AFTER_REACQUIRE_D,
    MODE3_STATE_GO_TO_E,
    MODE3_STATE_PREPARE_E_TURN,
    MODE3_STATE_TURN_E_TO_EDGE_1,
    MODE3_STATE_ALIGN_AFTER_E_TURN,
    MODE3_STATE_GO_TO_F,
    MODE3_STATE_TURN_AROUND_AT_F,
    MODE3_STATE_FIND_LINE_AFTER_F_TURN,
    MODE3_STATE_ALIGN_AFTER_F_TURN_AROUND,
    MODE3_STATE_RETURN_TO_E,
    MODE3_STATE_PREPARE_RETURN_E_TURN,
    MODE3_STATE_TURN_RETURN_E_TO_EDGE_8,
    MODE3_STATE_ALIGN_AFTER_RETURN_E_TURN,
    MODE3_STATE_RETURN_TO_D,
    MODE3_STATE_CROSS_GAP_TO_C,
    MODE3_STATE_ALIGN_AFTER_REACQUIRE_C,
    MODE3_STATE_RETURN_TO_B,
    MODE3_STATE_PREPARE_RETURN_B_TURN,
    MODE3_STATE_TURN_RETURN_B_TO_EDGE_1,
    MODE3_STATE_ALIGN_AFTER_RETURN_B_TURN,
    MODE3_STATE_RETURN_TO_A,
    MODE3_STATE_STOPPED
} Mode3State;

#define MODE3_TURN_SPEED                 (18U)
#define MODE3_CORNER_INNER_SPEED         (20U)
#define MODE3_CORNER_OUTER_SPEED         (29U)

static void mode3_follow_corner(CornerState cornerState)
{
    if (cornerState == CORNER_STATE_RIGHT) {
        motors_turn_right_speed(MODE3_CORNER_OUTER_SPEED, MODE3_CORNER_INNER_SPEED);
    } else {
        motors_turn_left_speed(MODE3_CORNER_INNER_SPEED, MODE3_CORNER_OUTER_SPEED);
    }
}

static void mode3_run_route_once(void)
{
    uint8_t lineSensorData = LINE_SENSOR_ALL_WHITE_DATA;
    uint16_t stateLoopCount = 0;
    uint16_t whiteLoopCount = 0;
    uint8_t rightCornerDetectCount = 0;
    uint8_t leftCornerDetectCount = 0;
    uint8_t centerStableCount = 0;
    int16_t currentYaw = 0;
    int16_t gapTargetYaw = 0;
    bool gyroValid = false;
    bool gapYawCaptured = false;
    bool lineRead = false;
    bool turnCenterLost = false;
    Mode3State routeState = MODE3_STATE_START_ALIGN_AB;
    LineSide lastLineSide = LINE_SIDE_RIGHT;

    while (1) {
        hwt101_update();
        gyroValid = hwt101_get_yaw_cdeg(&currentYaw);

        lineRead = line_sensor_read(&lineSensorData);
        if (!lineRead) {
            if (routeState == MODE3_STATE_CROSS_GAP_TO_D) {
                car_follow_gap_gyro(gapTargetYaw, currentYaw, gyroValid && gapYawCaptured);
            } else {
                motors_stop();
            }
            delay_ms(5);
            continue;
        }

        switch (routeState) {
        case MODE3_STATE_START_ALIGN_AB:
            stateLoopCount++;
            if (lineSensorData == LINE_SENSOR_ALL_WHITE_DATA) {
                centerStableCount = 0;
                car_follow_transient_white(lastLineSide);
            } else {
                car_follow_line_stable(lineSensorData, &lastLineSide);
                if (line_sensor_reacquired_center(lineSensorData)) {
                    centerStableCount++;
                } else {
                    centerStableCount = 0;
                }
            }

            if (centerStableCount >= LINE_SENSOR_STABLE_CENTER_COUNT) {
                routeState = MODE3_STATE_GO_FIRST_LINE;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                rightCornerDetectCount = 0;
            }
            break;

        case MODE3_STATE_GO_FIRST_LINE:
            stateLoopCount++;
            if ((stateLoopCount >= LINE_SENSOR_START_TURN_MIN_COUNT) &&
                line_sensor_detect_right_corner(lineSensorData)) {
                rightCornerDetectCount++;
            } else {
                rightCornerDetectCount = 0;
            }

            if (rightCornerDetectCount >= LINE_SENSOR_CORNER_TRIGGER_COUNT) {
                routeState = MODE3_STATE_PREPARE_FIRST_TURN;
                stateLoopCount = 0;
                rightCornerDetectCount = 0;
                whiteLoopCount = 0;
                centerStableCount = 0;
                motors_stop();
            } else if (lineSensorData != LINE_SENSOR_ALL_WHITE_DATA) {
                car_follow_line_stable(lineSensorData, &lastLineSide);
            } else {
                car_follow_transient_white(lastLineSide);
            }
            break;

        case MODE3_STATE_PREPARE_FIRST_TURN:
            stateLoopCount++;
            motors_stop();
            if (stateLoopCount >= LINE_SENSOR_BRANCH_STOP_COUNT) {
                routeState = MODE3_STATE_TURN_TO_EDGE_8;
                stateLoopCount = 0;
                centerStableCount = 0;
                turnCenterLost = false;
                lastLineSide = LINE_SIDE_RIGHT;
            }
            break;

        case MODE3_STATE_TURN_TO_EDGE_8:
            stateLoopCount++;
            mode3_follow_corner(CORNER_STATE_RIGHT);
            lastLineSide = LINE_SIDE_RIGHT;

            if ((stateLoopCount >= LINE_SENSOR_TURN_LOST_MIN_COUNT) &&
                !line_sensor_centered(lineSensorData)) {
                turnCenterLost = true;
            }
            if (!turnCenterLost || (stateLoopCount < LINE_SENSOR_CORNER_MIN_COUNT)) {
                centerStableCount = 0;
            } else if (line_sensor_reacquired_center(lineSensorData)) {
                centerStableCount++;
            } else {
                centerStableCount = 0;
            }

            if (centerStableCount >= LINE_SENSOR_CORNER_CENTER_COUNT) {
                routeState = MODE3_STATE_ALIGN_AFTER_FIRST_TURN;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                lastLineSide = LINE_SIDE_RIGHT;
            }
            break;

        case MODE3_STATE_ALIGN_AFTER_FIRST_TURN:
            stateLoopCount++;
            if (line_sensor_all_white_or_black(lineSensorData)) {
                whiteLoopCount++;
                centerStableCount = 0;
                car_hold_turn_direction(LINE_SIDE_RIGHT);
                if (whiteLoopCount <= LINE_SENSOR_TRANSIENT_INVALID_HOLD_COUNT) {
                    delay_ms(2U);
                }
            } else if (!line_sensor_centered(lineSensorData)) {
                whiteLoopCount = 0;
                centerStableCount = 0;
                car_turn_to_center_line(lineSensorData, LINE_SIDE_RIGHT);
            } else {
                whiteLoopCount = 0;
                centerStableCount++;
                car_follow_line_stable(lineSensorData, &lastLineSide);
            }

            if ((stateLoopCount >= LINE_SENSOR_STABLE_COUNT) &&
                (centerStableCount >= LINE_SENSOR_STABLE_CENTER_COUNT)) {
                routeState = MODE3_STATE_GO_TO_C;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                gapYawCaptured = false;
            }
            break;

        case MODE3_STATE_GO_TO_C:
            stateLoopCount++;
            if (lineSensorData == LINE_SENSOR_ALL_WHITE_DATA) {
                if (stateLoopCount >= LINE_SENSOR_C_MIN_LOOP_COUNT) {
                    whiteLoopCount++;
                    car_follow_transient_white(lastLineSide);
                    if (whiteLoopCount >= LINE_SENSOR_WHITE_STOP_COUNT) {
                        if (!gapYawCaptured && gyroValid) {
                            gapTargetYaw = currentYaw;
                            gapYawCaptured = true;
                        }
                        routeState = MODE3_STATE_CROSS_GAP_TO_D;
                        stateLoopCount = 0;
                        centerStableCount = 0;
                        whiteLoopCount = 0;
                    }
                } else {
                    whiteLoopCount = 0;
                    car_follow_transient_white(lastLineSide);
                }
            } else {
                whiteLoopCount = 0;
                if (!line_sensor_centered(lineSensorData)) {
                    centerStableCount = 0;
                    car_center_line_on_45(lineSensorData, &lastLineSide);
                } else {
                    centerStableCount++;
                    if (gyroValid) {
                        gapTargetYaw = currentYaw;
                        gapYawCaptured = true;
                    }
                    car_follow_line_stable(lineSensorData, &lastLineSide);
                }
            }
            break;

        case MODE3_STATE_CROSS_GAP_TO_D:
            stateLoopCount++;
            car_follow_gap_gyro(gapTargetYaw, currentYaw, gyroValid && gapYawCaptured);
            if ((stateLoopCount >= MODE2_GAP_MIN_LOOP_COUNT) &&
                (lineSensorData != LINE_SENSOR_ALL_WHITE_DATA) &&
                (lineSensorData != LINE_SENSOR_ALL_BLACK_DATA)) {
                routeState = MODE3_STATE_ALIGN_AFTER_REACQUIRE_D;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                lastLineSide = LINE_SIDE_RIGHT;
            }
            break;

        case MODE3_STATE_ALIGN_AFTER_REACQUIRE_D:
            stateLoopCount++;
            if (!line_sensor_centered(lineSensorData)) {
                centerStableCount = 0;
                mode3_reacquire_line_on_45(lineSensorData, &lastLineSide);
            } else {
                centerStableCount++;
                car_follow_line_stable(lineSensorData, &lastLineSide);
            }

            if (centerStableCount >= MODE2_D_CENTER_COUNT) {
                routeState = MODE3_STATE_GO_TO_E;
                stateLoopCount = 0;
                centerStableCount = 0;
                leftCornerDetectCount = 0;
            }
            break;

        case MODE3_STATE_GO_TO_E:
            stateLoopCount++;
            if ((stateLoopCount >= MODE2_E_MIN_LOOP_COUNT) &&
                ((lineSensorData & LINE_SENSOR_CENTER_MASK) != 0U) &&
                ((lineSensorData & LINE_SENSOR_LEFT_EDGE_MASK) != 0U)) {
                leftCornerDetectCount++;
            } else {
                leftCornerDetectCount = 0;
            }

            if (leftCornerDetectCount >= MODE2_E_STOP_COUNT) {
                routeState = MODE3_STATE_PREPARE_E_TURN;
                stateLoopCount = 0;
                leftCornerDetectCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                motors_stop();
            } else if (lineSensorData != LINE_SENSOR_ALL_WHITE_DATA) {
                if (!line_sensor_centered(lineSensorData)) {
                    car_center_line_on_45(lineSensorData, &lastLineSide);
                } else {
                    car_follow_line_stable(lineSensorData, &lastLineSide);
                }
            } else {
                car_follow_transient_white(lastLineSide);
            }
            break;

        case MODE3_STATE_PREPARE_E_TURN:
            stateLoopCount++;
            motors_stop();
            if (stateLoopCount >= LINE_SENSOR_BRANCH_STOP_COUNT) {
                routeState = MODE3_STATE_TURN_E_TO_EDGE_1;
                stateLoopCount = 0;
                centerStableCount = 0;
                turnCenterLost = false;
                lastLineSide = LINE_SIDE_LEFT;
            }
            break;

        case MODE3_STATE_TURN_E_TO_EDGE_1:
            stateLoopCount++;
            mode3_follow_corner(CORNER_STATE_LEFT);
            lastLineSide = LINE_SIDE_LEFT;

            if ((stateLoopCount >= LINE_SENSOR_TURN_LOST_MIN_COUNT) &&
                !line_sensor_centered(lineSensorData)) {
                turnCenterLost = true;
            }
            if (!turnCenterLost || (stateLoopCount < LINE_SENSOR_CORNER_MIN_COUNT)) {
                centerStableCount = 0;
            } else if (line_sensor_reacquired_center(lineSensorData)) {
                centerStableCount++;
            } else {
                centerStableCount = 0;
            }

            if (centerStableCount >= LINE_SENSOR_CORNER_CENTER_COUNT) {
                routeState = MODE3_STATE_ALIGN_AFTER_E_TURN;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                lastLineSide = LINE_SIDE_LEFT;
            }
            break;

        case MODE3_STATE_ALIGN_AFTER_E_TURN:
            stateLoopCount++;
            if (!line_sensor_centered(lineSensorData)) {
                centerStableCount = 0;
                car_turn_to_center_line(lineSensorData, LINE_SIDE_LEFT);
            } else {
                centerStableCount++;
                car_follow_line_stable(lineSensorData, &lastLineSide);
            }

            if ((stateLoopCount >= LINE_SENSOR_STABLE_COUNT) &&
                (centerStableCount >= LINE_SENSOR_STABLE_CENTER_COUNT)) {
                routeState = MODE3_STATE_GO_TO_F;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
            }
            break;

        case MODE3_STATE_GO_TO_F:
            stateLoopCount++;
            if (lineSensorData == LINE_SENSOR_ALL_WHITE_DATA) {
                if (stateLoopCount >= MODE3_F_MIN_LOOP_COUNT) {
                    whiteLoopCount++;
                    car_follow_transient_white(lastLineSide);
                    if (whiteLoopCount >= MODE3_F_WHITE_STOP_COUNT) {
                        return;
                    }
                } else {
                    whiteLoopCount = 0;
                    car_follow_transient_white(lastLineSide);
                }
            } else {
                whiteLoopCount = 0;
                if (!line_sensor_centered(lineSensorData)) {
                    car_center_line_on_45(lineSensorData, &lastLineSide);
                } else {
                    car_follow_line_stable(lineSensorData, &lastLineSide);
                }
            }
            break;

        default:
            motors_stop();
            return;
        }

        delay_ms(5);
    }
}

static void mode3_turn_around_between_runs(void)
{
    uint8_t lineSensorData = LINE_SENSOR_ALL_WHITE_DATA;
    uint16_t stateLoopCount = 0;
    uint8_t centerStableCount = 0;
    LineSide lastLineSide = LINE_SIDE_LEFT;

    while (1) {
        (void) line_sensor_read(&lineSensorData);
        stateLoopCount++;
        motors_turn_right_speed(MODE3_TURN_SPEED, MODE3_TURN_SPEED);
        lastLineSide = LINE_SIDE_LEFT;

        if ((stateLoopCount >= LINE_SENSOR_TURN_AROUND_MIN_COUNT) &&
            (lineSensorData != LINE_SENSOR_ALL_WHITE_DATA) &&
            (lineSensorData != LINE_SENSOR_ALL_BLACK_DATA)) {
            break;
        }

        delay_ms(5);
    }

    stateLoopCount = 0;
    while (1) {
        (void) line_sensor_read(&lineSensorData);
        stateLoopCount++;

        if (!line_sensor_centered(lineSensorData)) {
            centerStableCount = 0;
            car_turn_to_center_line(lineSensorData, LINE_SIDE_RIGHT);
        } else {
            centerStableCount++;
            car_follow_line_stable(lineSensorData, &lastLineSide);
        }

        if ((stateLoopCount >= LINE_SENSOR_STABLE_COUNT) &&
            (centerStableCount >= LINE_SENSOR_STABLE_CENTER_COUNT)) {
            return;
        }

        delay_ms(5);
    }
}

void mode3_run(void)
{
    mode3_run_route_once();
    mode3_turn_around_between_runs();
    mode3_run_route_once();
}

