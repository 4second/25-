#include "vision_uart.h"
#include "ti_msp_dl_config.h"

/*
 * 6 字节协议状态机定义：
 *   命中目标: S + Sign + D2 + D1 + D0 + E   (found=1, dx=解析值)
 *   丢失目标: N + 0  + 0  + 0  + 0  + E    (found=0, dx=0)
 */

#define VISION_FRAME_LEN        (6U)
#define VISION_HEADER_FOUND     ((uint8_t)'S')
#define VISION_HEADER_LOST      ((uint8_t)'N')
#define VISION_FOOTER           ((uint8_t)'E')
#define VISION_SIGN_PLUS        ((uint8_t)'+')
#define VISION_SIGN_MINUS       ((uint8_t)'-')

/* ---- volatile 全局变量定义 ---- */
volatile int16_t  target_dx    = 0;
volatile uint8_t  target_found = 0;

/* ---- 协议状态机静态变量 ---- */
static uint8_t  rx_buf[VISION_FRAME_LEN];
static uint8_t  rx_idx = 0;
static uint8_t  rx_header = 0;

void vision_uart_init(void)
{
    target_dx    = 0;
    target_found = 0;
    rx_idx       = 0;
    rx_header    = 0;
}

void uart_computer_INST_IRQHandler(void)
{
    uint8_t data;

    /*
     * 【防锁死机制】优先处理 OE/FE/PE/BE/NE 错误。
     * TI UART 在噪声干扰下极易触发 Overrun/Framing/Parity 错误，
     * 若不读取 RXDATA 来清除中断标志，UART 将永久停止响应。
     * 注意：MSPM0 SDK 没有统一的 IIDX_ERROR，每种错误是独立的 case。
     */
    switch (DL_UART_Main_getPendingInterrupt(uart_computer_INST)) {
    case DL_UART_MAIN_IIDX_OVERRUN_ERROR:
    case DL_UART_MAIN_IIDX_FRAMING_ERROR:
    case DL_UART_MAIN_IIDX_PARITY_ERROR:
    case DL_UART_MAIN_IIDX_BREAK_ERROR:
    case DL_UART_MAIN_IIDX_NOISE_ERROR:
        /* 读 RXDATA 清除错误中断标志，丢弃受损字节 */
        (void) DL_UART_Main_receiveDataBlocking(uart_computer_INST);
        return;

    case DL_UART_MAIN_IIDX_RX:
    case DL_UART_MAIN_IIDX_RX_TIMEOUT_ERROR:
        /* 正常接收：从 RXBUF 读出数据 */
        if (!DL_UART_Main_receiveDataCheck(uart_computer_INST, &data)) {
            return;
        }

        /*
         * 垃圾字符过滤：视觉模块帧尾可能附带 \r\n（0x0D 0x0A），
         * 直接忽略，不存入缓冲区也不影响当前状态机进度。
         */
        if (data == 0x0DU || data == 0x0AU) {
            return;
        }

        /* ---- 6 字节协议状态机 ---- */
        if (rx_idx == 0U) {
            /* 包头强制对齐：只接受 'S' 或 'N'，其余全部丢弃 */
            if (data == VISION_HEADER_FOUND || data == VISION_HEADER_LOST) {
                rx_header      = data;
                rx_buf[0]      = data;
                rx_idx         = 1;
            }
            return;
        }

        /* 收集中间字节 (index 1 ~ 4) */
        rx_buf[rx_idx] = data;
        rx_idx++;

        if (rx_idx < VISION_FRAME_LEN) {
            return;
        }

        /* 收满 6 字节，进行帧尾校验 */
        if (data != VISION_FOOTER) {
            /* 帧尾错误：安全复位，清空缓存和计数器 */
            rx_idx    = 0;
            rx_header = 0;
            return;
        }

        /* 帧尾正确，根据帧头解析 */
        if (rx_header == VISION_HEADER_LOST) {
            /* N 帧：目标丢失 */
            target_dx    = 0;
            target_found = 0;
        } else {
            /* S 帧：解析带符号的 3 位数字 (dx = ±000 ~ ±999) */
            int16_t dx_val = 0;
            uint8_t sign_byte = rx_buf[1];

            dx_val  = (int16_t)(rx_buf[2] - '0') * 100;
            dx_val += (int16_t)(rx_buf[3] - '0') * 10;
            dx_val += (int16_t)(rx_buf[4] - '0');

            if (sign_byte == VISION_SIGN_MINUS) {
                dx_val = (int16_t)(-dx_val);
            }
            /* sign_byte == '+' 或非法字符时保持正值（容错） */

            target_dx    = dx_val;
            target_found = 1;
        }

        /* 成功解析：安全复位，准备下一帧 */
        rx_idx    = 0;
        rx_header = 0;
        return;

    default:
        return;
    }
}
