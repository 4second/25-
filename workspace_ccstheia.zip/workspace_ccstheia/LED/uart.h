#ifndef UART_H
#define UART_H

#include <stdbool.h>
#include <stdint.h>

void uart_follow_send_char(uint8_t data);
uint8_t uart_follow_receive_char(void);
bool uart_follow_receive_char_check(uint8_t *data);

void uart_gyro_send_char(uint8_t data);
uint8_t uart_gyro_receive_char(void);
bool uart_gyro_receive_char_check(uint8_t *data);

#endif
