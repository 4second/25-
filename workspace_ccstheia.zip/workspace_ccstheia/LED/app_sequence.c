#include "app_sequence.h"

#include "app_common.h"
#include "mode1.h"
#include "mode2.h"
#include "mode3.h"
#include "mode4.h"

void app_run_all_modes(void)
{
    ModeResult mode1Result;
    ModeResult mode2Result;

    app_wait_button_press();
    app_buzzer_beep();
    mode1Result = mode1_run();
    if (mode1Result == MODE_RESULT_DONE) {
        app_buzzer_beep();
        app_wait_button_press();
    }

    app_buzzer_beep_times(2U);
    mode2Result = mode2_run();
    if (mode2Result == MODE_RESULT_DONE) {
        app_buzzer_beep();
        app_wait_button_press();
    }

    app_buzzer_beep_times(3U);
    mode3_run();
    app_buzzer_beep();
    app_wait_button_press();

    app_buzzer_beep_times(4U);
    mode4_run();
}
