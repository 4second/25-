#ifndef MODE2_H
#define MODE2_H

#include "app_common.h"

ModeResult mode2_run(void);

#endif
