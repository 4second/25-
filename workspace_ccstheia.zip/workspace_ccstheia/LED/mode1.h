#ifndef MODE1_H
#define MODE1_H

#include "app_common.h"

ModeResult mode1_run(void);

#endif
