#include "motor.h"
#include "ti_msp_dl_config.h"

#define MOTOR_PWM_PERIOD                  (2000U)
#define MOTOR_BASE_SPEED_PERCENT          (35U)
#define MOTOR_PWM_STOP_COMPARE            (0U)
#define MOTOR_PWM_BRAKE_COMPARE           (MOTOR_PWM_PERIOD - 1U)
#define MOTOR_PWM_MAX_DUTY_PERCENT        (100U)

static uint32_t motor_percent_to_compare(uint8_t percent)
{
    if (percent == 0U) {
        return MOTOR_PWM_STOP_COMPARE;
    }

    if (percent > MOTOR_PWM_MAX_DUTY_PERCENT) {
        percent = MOTOR_PWM_MAX_DUTY_PERCENT;
    }

    return ((MOTOR_PWM_PERIOD * percent) / 100U) - 1U;
}

void motors_init(void)
{
    motors_stop();
    DL_TimerG_startCounter(pwmA_INST);
    DL_TimerG_startCounter(pwmB_INST);
}

void motors_stop(void)
{
    DL_TimerG_setCaptureCompareValue(pwmA_INST, MOTOR_PWM_BRAKE_COMPARE, GPIO_pwmA_C1_IDX);
    DL_TimerG_setCaptureCompareValue(pwmB_INST, MOTOR_PWM_BRAKE_COMPARE, GPIO_pwmB_C1_IDX);
    DL_GPIO_setPins(ain1_PORT, ain1_PIN_0_PIN);
    DL_GPIO_setPins(ain2_PORT, ain2_PIN_1_PIN);
    DL_GPIO_setPins(bin1_PORT, bin1_PIN_3_PIN);
    DL_GPIO_setPins(bin2_PORT, bin2_PIN_2_PIN);
}

void motors_forward(void)
{
    motors_forward_speed(MOTOR_BASE_SPEED_PERCENT, MOTOR_BASE_SPEED_PERCENT);
}

void motors_forward_speed(uint8_t leftPercent, uint8_t rightPercent)
{
    DL_GPIO_setPins(ain1_PORT, ain1_PIN_0_PIN);
    DL_GPIO_clearPins(ain2_PORT, ain2_PIN_1_PIN);
    DL_GPIO_setPins(bin1_PORT, bin1_PIN_3_PIN);
    DL_GPIO_clearPins(bin2_PORT, bin2_PIN_2_PIN);
    DL_TimerG_setCaptureCompareValue(pwmA_INST, motor_percent_to_compare(leftPercent), GPIO_pwmA_C1_IDX);
    DL_TimerG_setCaptureCompareValue(pwmB_INST, motor_percent_to_compare(rightPercent), GPIO_pwmB_C1_IDX);
}

void motors_turn_left_speed(uint8_t leftPercent, uint8_t rightPercent)
{
    DL_GPIO_clearPins(ain1_PORT, ain1_PIN_0_PIN);
    DL_GPIO_setPins(ain2_PORT, ain2_PIN_1_PIN);
    DL_GPIO_setPins(bin1_PORT, bin1_PIN_3_PIN);
    DL_GPIO_clearPins(bin2_PORT, bin2_PIN_2_PIN);
    DL_TimerG_setCaptureCompareValue(pwmA_INST, motor_percent_to_compare(leftPercent), GPIO_pwmA_C1_IDX);
    DL_TimerG_setCaptureCompareValue(pwmB_INST, motor_percent_to_compare(rightPercent), GPIO_pwmB_C1_IDX);
}

void motors_turn_right_speed(uint8_t leftPercent, uint8_t rightPercent)
{
    DL_GPIO_setPins(ain1_PORT, ain1_PIN_0_PIN);
    DL_GPIO_clearPins(ain2_PORT, ain2_PIN_1_PIN);
    DL_GPIO_clearPins(bin1_PORT, bin1_PIN_3_PIN);
    DL_GPIO_setPins(bin2_PORT, bin2_PIN_2_PIN);
    DL_TimerG_setCaptureCompareValue(pwmA_INST, motor_percent_to_compare(leftPercent), GPIO_pwmA_C1_IDX);
    DL_TimerG_setCaptureCompareValue(pwmB_INST, motor_percent_to_compare(rightPercent), GPIO_pwmB_C1_IDX);
}
