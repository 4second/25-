#include "uart.h"
#include "ti_msp_dl_config.h"

void uart_follow_send_char(uint8_t data)
{
    DL_UART_Main_transmitDataBlocking(uart_follow_INST, data);
}

uint8_t uart_follow_receive_char(void)
{
    return DL_UART_Main_receiveDataBlocking(uart_follow_INST);
}

bool uart_follow_receive_char_check(uint8_t *data)
{
    return DL_UART_Main_receiveDataCheck(uart_follow_INST, data);
}

void uart_gyro_send_char(uint8_t data)
{
    DL_UART_Main_transmitDataBlocking(uart_gyro_INST, data);
}

uint8_t uart_gyro_receive_char(void)
{
    return DL_UART_Main_receiveDataBlocking(uart_gyro_INST);
}

bool uart_gyro_receive_char_check(uint8_t *data)
{
    return DL_UART_Main_receiveDataCheck(uart_gyro_INST, data);
}
