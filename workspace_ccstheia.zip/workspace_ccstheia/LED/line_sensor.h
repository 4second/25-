#ifndef LINE_SENSOR_H
#define LINE_SENSOR_H

#include <stdbool.h>
#include <stdint.h>

#define LINE_SENSOR_REQUEST_CMD      (0x57U)
#define LINE_SENSOR_TIMEOUT_MS       (200U)

bool line_sensor_read(uint8_t *data);

#endif
