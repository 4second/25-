# FIXED

hwt101.o: ../hwt101.c ../hwt101.h ../uart.h
../hwt101.h:
../uart.h:
