################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
SYSCFG_SRCS += \
../empty.syscfg 

C_SRCS += \
../app_common.c \
../app_sequence.c \
../delay.c \
../empty.c \
./ti_msp_dl_config.c \
D:/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c \
../hwt101.c \
../line_sensor.c \
../mode1.c \
../mode2.c \
../mode3.c \
../mode4.c \
../motor.c \
../uart.c \
../vision_uart.c 

GEN_CMDS += \
./device_linker.cmd 

GEN_FILES += \
./device_linker.cmd \
./device.opt \
./ti_msp_dl_config.c 

C_DEPS += \
./app_common.d \
./app_sequence.d \
./delay.d \
./empty.d \
./ti_msp_dl_config.d \
./startup_mspm0g350x_ticlang.d \
./hwt101.d \
./line_sensor.d \
./mode1.d \
./mode2.d \
./mode3.d \
./mode4.d \
./motor.d \
./uart.d \
./vision_uart.d 

GEN_OPTS += \
./device.opt 

OBJS += \
./app_common.o \
./app_sequence.o \
./delay.o \
./empty.o \
./ti_msp_dl_config.o \
./startup_mspm0g350x_ticlang.o \
./hwt101.o \
./line_sensor.o \
./mode1.o \
./mode2.o \
./mode3.o \
./mode4.o \
./motor.o \
./uart.o \
./vision_uart.o 

GEN_MISC_FILES += \
./device.cmd.genlibs \
./ti_msp_dl_config.h \
./Event.dot 

OBJS__QUOTED += \
"app_common.o" \
"app_sequence.o" \
"delay.o" \
"empty.o" \
"ti_msp_dl_config.o" \
"startup_mspm0g350x_ticlang.o" \
"hwt101.o" \
"line_sensor.o" \
"mode1.o" \
"mode2.o" \
"mode3.o" \
"mode4.o" \
"motor.o" \
"uart.o" \
"vision_uart.o" 

GEN_MISC_FILES__QUOTED += \
"device.cmd.genlibs" \
"ti_msp_dl_config.h" \
"Event.dot" 

C_DEPS__QUOTED += \
"app_common.d" \
"app_sequence.d" \
"delay.d" \
"empty.d" \
"ti_msp_dl_config.d" \
"startup_mspm0g350x_ticlang.d" \
"hwt101.d" \
"line_sensor.d" \
"mode1.d" \
"mode2.d" \
"mode3.d" \
"mode4.d" \
"motor.d" \
"uart.d" \
"vision_uart.d" 

GEN_FILES__QUOTED += \
"device_linker.cmd" \
"device.opt" \
"ti_msp_dl_config.c" 

C_SRCS__QUOTED += \
"../app_common.c" \
"../app_sequence.c" \
"../delay.c" \
"../empty.c" \
"./ti_msp_dl_config.c" \
"D:/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0g350x_ticlang.c" \
"../hwt101.c" \
"../line_sensor.c" \
"../mode1.c" \
"../mode2.c" \
"../mode3.c" \
"../mode4.c" \
"../motor.c" \
"../uart.c" \
"../vision_uart.c" 

SYSCFG_SRCS__QUOTED += \
"../empty.syscfg" 


