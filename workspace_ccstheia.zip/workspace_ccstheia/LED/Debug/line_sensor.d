# FIXED

line_sensor.o: ../line_sensor.c ../line_sensor.h ../delay.h ../uart.h
../line_sensor.h:
../delay.h:
../uart.h:
