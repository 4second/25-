# FIXED

mode1.o: ../mode1.c ../mode1.h ../app_common.h ../delay.h ../hwt101.h \
 ../line_sensor.h ../motor.h
../mode1.h:
../app_common.h:
../delay.h:
../hwt101.h:
../line_sensor.h:
../motor.h:
