# FIXED

mode3.o: ../mode3.c ../mode3.h ../app_common.h ../delay.h ../hwt101.h \
 ../line_sensor.h ../motor.h
../mode3.h:
../app_common.h:
../delay.h:
../hwt101.h:
../line_sensor.h:
../motor.h:
