/*
 * Copyright (c) 2023, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.c =============
 *  Configured MSPM0 DriverLib module definitions
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */

#include "ti_msp_dl_config.h"

DL_TimerG_backupConfig gpwmABackup;
DL_UART_Main_backupConfig guart_followBackup;

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform any initialization needed before using any board APIs
 */
SYSCONFIG_WEAK void SYSCFG_DL_init(void)
{
    SYSCFG_DL_initPower();
    SYSCFG_DL_GPIO_init();
    /* Module-Specific Initializations*/
    SYSCFG_DL_SYSCTL_init();
    SYSCFG_DL_pwmA_init();
    SYSCFG_DL_pwmB_init();
    SYSCFG_DL_uart_follow_init();
    SYSCFG_DL_uart_gyro_init();
    SYSCFG_DL_uart_computer_init();
    /* Ensure backup structures have no valid state */
	gpwmABackup.backupRdy 	= false;
	guart_followBackup.backupRdy 	= false;

}
/*
 * User should take care to save and restore register configuration in application.
 * See Retention Configuration section for more details.
 */
SYSCONFIG_WEAK bool SYSCFG_DL_saveConfiguration(void)
{
    bool retStatus = true;

	retStatus &= DL_TimerG_saveConfiguration(pwmA_INST, &gpwmABackup);
	retStatus &= DL_UART_Main_saveConfiguration(uart_follow_INST, &guart_followBackup);

    return retStatus;
}


SYSCONFIG_WEAK bool SYSCFG_DL_restoreConfiguration(void)
{
    bool retStatus = true;

	retStatus &= DL_TimerG_restoreConfiguration(pwmA_INST, &gpwmABackup, false);
	retStatus &= DL_UART_Main_restoreConfiguration(uart_follow_INST, &guart_followBackup);

    return retStatus;
}

SYSCONFIG_WEAK void SYSCFG_DL_initPower(void)
{
    DL_GPIO_reset(GPIOA);
    DL_GPIO_reset(GPIOB);
    DL_TimerG_reset(pwmA_INST);
    DL_TimerG_reset(pwmB_INST);
    DL_UART_Main_reset(uart_follow_INST);
    DL_UART_Main_reset(uart_gyro_INST);
    DL_UART_Main_reset(uart_computer_INST);

    DL_GPIO_enablePower(GPIOA);
    DL_GPIO_enablePower(GPIOB);
    DL_TimerG_enablePower(pwmA_INST);
    DL_TimerG_enablePower(pwmB_INST);
    DL_UART_Main_enablePower(uart_follow_INST);
    DL_UART_Main_enablePower(uart_gyro_INST);
    DL_UART_Main_enablePower(uart_computer_INST);
    delay_cycles(POWER_STARTUP_DELAY);
}

SYSCONFIG_WEAK void SYSCFG_DL_GPIO_init(void)
{

    DL_GPIO_initPeripheralOutputFunction(GPIO_pwmA_C1_IOMUX,GPIO_pwmA_C1_IOMUX_FUNC);
    DL_GPIO_enableOutput(GPIO_pwmA_C1_PORT, GPIO_pwmA_C1_PIN);
    DL_GPIO_initPeripheralOutputFunction(GPIO_pwmB_C1_IOMUX,GPIO_pwmB_C1_IOMUX_FUNC);
    DL_GPIO_enableOutput(GPIO_pwmB_C1_PORT, GPIO_pwmB_C1_PIN);

    DL_GPIO_initPeripheralOutputFunction(
        GPIO_uart_follow_IOMUX_TX, GPIO_uart_follow_IOMUX_TX_FUNC);
    DL_GPIO_initPeripheralInputFunction(
        GPIO_uart_follow_IOMUX_RX, GPIO_uart_follow_IOMUX_RX_FUNC);
    DL_GPIO_initPeripheralOutputFunction(
        GPIO_uart_gyro_IOMUX_TX, GPIO_uart_gyro_IOMUX_TX_FUNC);
    DL_GPIO_initPeripheralInputFunction(
        GPIO_uart_gyro_IOMUX_RX, GPIO_uart_gyro_IOMUX_RX_FUNC);
    DL_GPIO_initPeripheralOutputFunction(
        GPIO_uart_computer_IOMUX_TX, GPIO_uart_computer_IOMUX_TX_FUNC);
    DL_GPIO_initPeripheralInputFunction(
        GPIO_uart_computer_IOMUX_RX, GPIO_uart_computer_IOMUX_RX_FUNC);

    DL_GPIO_initDigitalOutput(ain1_PIN_0_IOMUX);

    DL_GPIO_initDigitalOutput(ain2_PIN_1_IOMUX);

    DL_GPIO_initDigitalOutput(bin2_PIN_2_IOMUX);

    DL_GPIO_initDigitalOutput(bin1_PIN_3_IOMUX);

    DL_GPIO_initDigitalOutput(buzzer_PIN_4_IOMUX);

    DL_GPIO_initDigitalInputFeatures(key_PIN_5_IOMUX,
		 DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
		 DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);

    DL_GPIO_clearPins(GPIOA, ain1_PIN_0_PIN |
		bin2_PIN_2_PIN |
		bin1_PIN_3_PIN |
		buzzer_PIN_4_PIN);
    DL_GPIO_enableOutput(GPIOA, ain1_PIN_0_PIN |
		bin2_PIN_2_PIN |
		bin1_PIN_3_PIN |
		buzzer_PIN_4_PIN);
    DL_GPIO_clearPins(GPIOB, ain2_PIN_1_PIN);
    DL_GPIO_enableOutput(GPIOB, ain2_PIN_1_PIN);

}


SYSCONFIG_WEAK void SYSCFG_DL_SYSCTL_init(void)
{

	//Low Power Mode is configured to be SLEEP0
    DL_SYSCTL_setBORThreshold(DL_SYSCTL_BOR_THRESHOLD_LEVEL_0);

    DL_SYSCTL_setSYSOSCFreq(DL_SYSCTL_SYSOSC_FREQ_BASE);
    /* Set default configuration */
    DL_SYSCTL_disableHFXT();
    DL_SYSCTL_disableSYSPLL();
    DL_SYSCTL_setULPCLKDivider(DL_SYSCTL_ULPCLK_DIV_1);
    DL_SYSCTL_setMCLKDivider(DL_SYSCTL_MCLK_DIVIDER_DISABLE);

}


/*
 * Timer clock configuration to be sourced by  / 8 (4000000 Hz)
 * timerClkFreq = (timerClkSrc / (timerClkDivRatio * (timerClkPrescale + 1)))
 *   40000 Hz = 4000000 Hz / (8 * (99 + 1))
 */
static const DL_TimerG_ClockConfig gpwmAClockConfig = {
    .clockSel = DL_TIMER_CLOCK_BUSCLK,
    .divideRatio = DL_TIMER_CLOCK_DIVIDE_8,
    .prescale = 99U
};

static const DL_TimerG_PWMConfig gpwmAConfig = {
    .pwmMode = DL_TIMER_PWM_MODE_EDGE_ALIGN_UP,
    .period = 2000,
    .isTimerWithFourCC = false,
    .startTimer = DL_TIMER_START,
};

SYSCONFIG_WEAK void SYSCFG_DL_pwmA_init(void) {

    DL_TimerG_setClockConfig(
        pwmA_INST, (DL_TimerG_ClockConfig *) &gpwmAClockConfig);

    DL_TimerG_initPWMMode(
        pwmA_INST, (DL_TimerG_PWMConfig *) &gpwmAConfig);

    // Set Counter control to the smallest CC index being used
    DL_TimerG_setCounterControl(pwmA_INST,DL_TIMER_CZC_CCCTL1_ZCOND,DL_TIMER_CAC_CCCTL1_ACOND,DL_TIMER_CLC_CCCTL1_LCOND);

    DL_TimerG_setCaptureCompareOutCtl(pwmA_INST, DL_TIMER_CC_OCTL_INIT_VAL_LOW,
		DL_TIMER_CC_OCTL_INV_OUT_DISABLED, DL_TIMER_CC_OCTL_SRC_FUNCVAL,
		DL_TIMERG_CAPTURE_COMPARE_1_INDEX);

    DL_TimerG_setCaptCompUpdateMethod(pwmA_INST, DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, DL_TIMERG_CAPTURE_COMPARE_1_INDEX);
    DL_TimerG_setCaptureCompareValue(pwmA_INST, 149, DL_TIMER_CC_1_INDEX);

    DL_TimerG_enableClock(pwmA_INST);


    
    DL_TimerG_setCCPDirection(pwmA_INST , DL_TIMER_CC1_OUTPUT );


}
/*
 * Timer clock configuration to be sourced by  / 8 (4000000 Hz)
 * timerClkFreq = (timerClkSrc / (timerClkDivRatio * (timerClkPrescale + 1)))
 *   40000 Hz = 4000000 Hz / (8 * (99 + 1))
 */
static const DL_TimerG_ClockConfig gpwmBClockConfig = {
    .clockSel = DL_TIMER_CLOCK_BUSCLK,
    .divideRatio = DL_TIMER_CLOCK_DIVIDE_8,
    .prescale = 99U
};

static const DL_TimerG_PWMConfig gpwmBConfig = {
    .pwmMode = DL_TIMER_PWM_MODE_EDGE_ALIGN_UP,
    .period = 2000,
    .isTimerWithFourCC = false,
    .startTimer = DL_TIMER_START,
};

SYSCONFIG_WEAK void SYSCFG_DL_pwmB_init(void) {

    DL_TimerG_setClockConfig(
        pwmB_INST, (DL_TimerG_ClockConfig *) &gpwmBClockConfig);

    DL_TimerG_initPWMMode(
        pwmB_INST, (DL_TimerG_PWMConfig *) &gpwmBConfig);

    // Set Counter control to the smallest CC index being used
    DL_TimerG_setCounterControl(pwmB_INST,DL_TIMER_CZC_CCCTL1_ZCOND,DL_TIMER_CAC_CCCTL1_ACOND,DL_TIMER_CLC_CCCTL1_LCOND);

    DL_TimerG_setCaptureCompareOutCtl(pwmB_INST, DL_TIMER_CC_OCTL_INIT_VAL_LOW,
		DL_TIMER_CC_OCTL_INV_OUT_DISABLED, DL_TIMER_CC_OCTL_SRC_FUNCVAL,
		DL_TIMERG_CAPTURE_COMPARE_1_INDEX);

    DL_TimerG_setCaptCompUpdateMethod(pwmB_INST, DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, DL_TIMERG_CAPTURE_COMPARE_1_INDEX);
    DL_TimerG_setCaptureCompareValue(pwmB_INST, 149, DL_TIMER_CC_1_INDEX);

    DL_TimerG_enableClock(pwmB_INST);


    
    DL_TimerG_setCCPDirection(pwmB_INST , DL_TIMER_CC1_OUTPUT );


}


static const DL_UART_Main_ClockConfig guart_followClockConfig = {
    .clockSel    = DL_UART_MAIN_CLOCK_BUSCLK,
    .divideRatio = DL_UART_MAIN_CLOCK_DIVIDE_RATIO_1
};

static const DL_UART_Main_Config guart_followConfig = {
    .mode        = DL_UART_MAIN_MODE_NORMAL,
    .direction   = DL_UART_MAIN_DIRECTION_TX_RX,
    .flowControl = DL_UART_MAIN_FLOW_CONTROL_NONE,
    .parity      = DL_UART_MAIN_PARITY_NONE,
    .wordLength  = DL_UART_MAIN_WORD_LENGTH_8_BITS,
    .stopBits    = DL_UART_MAIN_STOP_BITS_ONE
};

SYSCONFIG_WEAK void SYSCFG_DL_uart_follow_init(void)
{
    DL_UART_Main_setClockConfig(uart_follow_INST, (DL_UART_Main_ClockConfig *) &guart_followClockConfig);

    DL_UART_Main_init(uart_follow_INST, (DL_UART_Main_Config *) &guart_followConfig);
    /*
     * Configure baud rate by setting oversampling and baud rate divisors.
     *  Target baud rate: 9600
     *  Actual baud rate: 9600.24
     */
    DL_UART_Main_setOversampling(uart_follow_INST, DL_UART_OVERSAMPLING_RATE_16X);
    DL_UART_Main_setBaudRateDivisor(uart_follow_INST, uart_follow_IBRD_32_MHZ_9600_BAUD, uart_follow_FBRD_32_MHZ_9600_BAUD);



    DL_UART_Main_enable(uart_follow_INST);
}
static const DL_UART_Main_ClockConfig guart_gyroClockConfig = {
    .clockSel    = DL_UART_MAIN_CLOCK_BUSCLK,
    .divideRatio = DL_UART_MAIN_CLOCK_DIVIDE_RATIO_1
};

static const DL_UART_Main_Config guart_gyroConfig = {
    .mode        = DL_UART_MAIN_MODE_NORMAL,
    .direction   = DL_UART_MAIN_DIRECTION_TX_RX,
    .flowControl = DL_UART_MAIN_FLOW_CONTROL_NONE,
    .parity      = DL_UART_MAIN_PARITY_NONE,
    .wordLength  = DL_UART_MAIN_WORD_LENGTH_8_BITS,
    .stopBits    = DL_UART_MAIN_STOP_BITS_ONE
};

SYSCONFIG_WEAK void SYSCFG_DL_uart_gyro_init(void)
{
    DL_UART_Main_setClockConfig(uart_gyro_INST, (DL_UART_Main_ClockConfig *) &guart_gyroClockConfig);

    DL_UART_Main_init(uart_gyro_INST, (DL_UART_Main_Config *) &guart_gyroConfig);
    /*
     * Configure baud rate by setting oversampling and baud rate divisors.
     *  Target baud rate: 115200
     *  Actual baud rate: 115211.52
     */
    DL_UART_Main_setOversampling(uart_gyro_INST, DL_UART_OVERSAMPLING_RATE_16X);
    DL_UART_Main_setBaudRateDivisor(uart_gyro_INST, uart_gyro_IBRD_32_MHZ_115200_BAUD, uart_gyro_FBRD_32_MHZ_115200_BAUD);



    DL_UART_Main_enable(uart_gyro_INST);
}
static const DL_UART_Main_ClockConfig guart_computerClockConfig = {
    .clockSel    = DL_UART_MAIN_CLOCK_BUSCLK,
    .divideRatio = DL_UART_MAIN_CLOCK_DIVIDE_RATIO_1
};

static const DL_UART_Main_Config guart_computerConfig = {
    .mode        = DL_UART_MAIN_MODE_NORMAL,
    .direction   = DL_UART_MAIN_DIRECTION_TX_RX,
    .flowControl = DL_UART_MAIN_FLOW_CONTROL_NONE,
    .parity      = DL_UART_MAIN_PARITY_NONE,
    .wordLength  = DL_UART_MAIN_WORD_LENGTH_8_BITS,
    .stopBits    = DL_UART_MAIN_STOP_BITS_ONE
};

SYSCONFIG_WEAK void SYSCFG_DL_uart_computer_init(void)
{
    DL_UART_Main_setClockConfig(uart_computer_INST, (DL_UART_Main_ClockConfig *) &guart_computerClockConfig);

    DL_UART_Main_init(uart_computer_INST, (DL_UART_Main_Config *) &guart_computerConfig);
    /*
     * Configure baud rate by setting oversampling and baud rate divisors.
     *  Target baud rate: 9600
     *  Actual baud rate: 9600.24
     */
    DL_UART_Main_setOversampling(uart_computer_INST, DL_UART_OVERSAMPLING_RATE_16X);
    DL_UART_Main_setBaudRateDivisor(uart_computer_INST, uart_computer_IBRD_32_MHZ_9600_BAUD, uart_computer_FBRD_32_MHZ_9600_BAUD);



    DL_UART_Main_enable(uart_computer_INST);
}

