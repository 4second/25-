# FIXED

app_sequence.o: ../app_sequence.c ../app_sequence.h ../app_common.h \
 ../mode1.h ../mode2.h ../mode3.h ../mode4.h
../app_sequence.h:
../app_common.h:
../mode1.h:
../mode2.h:
../mode3.h:
../mode4.h:
