/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define CPUCLK_FREQ                                                     32000000



/* Defines for pwmA */
#define pwmA_INST                                                          TIMG7
#define pwmA_INST_IRQHandler                                    TIMG7_IRQHandler
#define pwmA_INST_INT_IRQN                                      (TIMG7_INT_IRQn)
#define pwmA_INST_CLK_FREQ                                                 40000
/* GPIO defines for channel 1 */
#define GPIO_pwmA_C1_PORT                                                  GPIOA
#define GPIO_pwmA_C1_PIN                                          DL_GPIO_PIN_24
#define GPIO_pwmA_C1_IOMUX                                       (IOMUX_PINCM54)
#define GPIO_pwmA_C1_IOMUX_FUNC                      IOMUX_PINCM54_PF_TIMG7_CCP1
#define GPIO_pwmA_C1_IDX                                     DL_TIMER_CC_1_INDEX

/* Defines for pwmB */
#define pwmB_INST                                                          TIMG8
#define pwmB_INST_IRQHandler                                    TIMG8_IRQHandler
#define pwmB_INST_INT_IRQN                                      (TIMG8_INT_IRQn)
#define pwmB_INST_CLK_FREQ                                                 40000
/* GPIO defines for channel 1 */
#define GPIO_pwmB_C1_PORT                                                  GPIOA
#define GPIO_pwmB_C1_PIN                                          DL_GPIO_PIN_22
#define GPIO_pwmB_C1_IOMUX                                       (IOMUX_PINCM47)
#define GPIO_pwmB_C1_IOMUX_FUNC                      IOMUX_PINCM47_PF_TIMG8_CCP1
#define GPIO_pwmB_C1_IDX                                     DL_TIMER_CC_1_INDEX



/* Defines for uart_follow */
#define uart_follow_INST                                                   UART3
#define uart_follow_INST_FREQUENCY                                      32000000
#define uart_follow_INST_IRQHandler                             UART3_IRQHandler
#define uart_follow_INST_INT_IRQN                                 UART3_INT_IRQn
#define GPIO_uart_follow_RX_PORT                                           GPIOB
#define GPIO_uart_follow_TX_PORT                                           GPIOB
#define GPIO_uart_follow_RX_PIN                                   DL_GPIO_PIN_13
#define GPIO_uart_follow_TX_PIN                                   DL_GPIO_PIN_12
#define GPIO_uart_follow_IOMUX_RX                                (IOMUX_PINCM30)
#define GPIO_uart_follow_IOMUX_TX                                (IOMUX_PINCM29)
#define GPIO_uart_follow_IOMUX_RX_FUNC                 IOMUX_PINCM30_PF_UART3_RX
#define GPIO_uart_follow_IOMUX_TX_FUNC                 IOMUX_PINCM29_PF_UART3_TX
#define uart_follow_BAUD_RATE                                             (9600)
#define uart_follow_IBRD_32_MHZ_9600_BAUD                                  (208)
#define uart_follow_FBRD_32_MHZ_9600_BAUD                                   (21)
/* Defines for uart_gyro */
#define uart_gyro_INST                                                     UART0
#define uart_gyro_INST_FREQUENCY                                        32000000
#define uart_gyro_INST_IRQHandler                               UART0_IRQHandler
#define uart_gyro_INST_INT_IRQN                                   UART0_INT_IRQn
#define GPIO_uart_gyro_RX_PORT                                             GPIOA
#define GPIO_uart_gyro_TX_PORT                                             GPIOA
#define GPIO_uart_gyro_RX_PIN                                      DL_GPIO_PIN_1
#define GPIO_uart_gyro_TX_PIN                                      DL_GPIO_PIN_0
#define GPIO_uart_gyro_IOMUX_RX                                   (IOMUX_PINCM2)
#define GPIO_uart_gyro_IOMUX_TX                                   (IOMUX_PINCM1)
#define GPIO_uart_gyro_IOMUX_RX_FUNC                    IOMUX_PINCM2_PF_UART0_RX
#define GPIO_uart_gyro_IOMUX_TX_FUNC                    IOMUX_PINCM1_PF_UART0_TX
#define uart_gyro_BAUD_RATE                                             (115200)
#define uart_gyro_IBRD_32_MHZ_115200_BAUD                                   (17)
#define uart_gyro_FBRD_32_MHZ_115200_BAUD                                   (23)
/* Defines for uart_computer */
#define uart_computer_INST                                                 UART1
#define uart_computer_INST_FREQUENCY                                    32000000
#define uart_computer_INST_IRQHandler                           UART1_IRQHandler
#define uart_computer_INST_INT_IRQN                               UART1_INT_IRQn
#define GPIO_uart_computer_RX_PORT                                         GPIOB
#define GPIO_uart_computer_TX_PORT                                         GPIOB
#define GPIO_uart_computer_RX_PIN                                  DL_GPIO_PIN_5
#define GPIO_uart_computer_TX_PIN                                  DL_GPIO_PIN_4
#define GPIO_uart_computer_IOMUX_RX                              (IOMUX_PINCM18)
#define GPIO_uart_computer_IOMUX_TX                              (IOMUX_PINCM17)
#define GPIO_uart_computer_IOMUX_RX_FUNC               IOMUX_PINCM18_PF_UART1_RX
#define GPIO_uart_computer_IOMUX_TX_FUNC               IOMUX_PINCM17_PF_UART1_TX
#define uart_computer_BAUD_RATE                                           (9600)
#define uart_computer_IBRD_32_MHZ_9600_BAUD                                (208)
#define uart_computer_FBRD_32_MHZ_9600_BAUD                                 (21)





/* Port definition for Pin Group ain1 */
#define ain1_PORT                                                        (GPIOA)

/* Defines for PIN_0: GPIOA.26 with pinCMx 59 on package pin 30 */
#define ain1_PIN_0_PIN                                          (DL_GPIO_PIN_26)
#define ain1_PIN_0_IOMUX                                         (IOMUX_PINCM59)
/* Port definition for Pin Group ain2 */
#define ain2_PORT                                                        (GPIOB)

/* Defines for PIN_1: GPIOB.24 with pinCMx 52 on package pin 23 */
#define ain2_PIN_1_PIN                                          (DL_GPIO_PIN_24)
#define ain2_PIN_1_IOMUX                                         (IOMUX_PINCM52)
/* Port definition for Pin Group bin2 */
#define bin2_PORT                                                        (GPIOA)

/* Defines for PIN_2: GPIOA.15 with pinCMx 37 on package pin 8 */
#define bin2_PIN_2_PIN                                          (DL_GPIO_PIN_15)
#define bin2_PIN_2_IOMUX                                         (IOMUX_PINCM37)
/* Port definition for Pin Group bin1 */
#define bin1_PORT                                                        (GPIOA)

/* Defines for PIN_3: GPIOA.17 with pinCMx 39 on package pin 10 */
#define bin1_PIN_3_PIN                                          (DL_GPIO_PIN_17)
#define bin1_PIN_3_IOMUX                                         (IOMUX_PINCM39)
/* Port definition for Pin Group buzzer */
#define buzzer_PORT                                                      (GPIOA)

/* Defines for PIN_4: GPIOA.16 with pinCMx 38 on package pin 9 */
#define buzzer_PIN_4_PIN                                        (DL_GPIO_PIN_16)
#define buzzer_PIN_4_IOMUX                                       (IOMUX_PINCM38)
/* Port definition for Pin Group key */
#define key_PORT                                                         (GPIOB)

/* Defines for PIN_5: GPIOB.21 with pinCMx 49 on package pin 20 */
#define key_PIN_5_PIN                                           (DL_GPIO_PIN_21)
#define key_PIN_5_IOMUX                                          (IOMUX_PINCM49)


/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_pwmA_init(void);
void SYSCFG_DL_pwmB_init(void);
void SYSCFG_DL_uart_follow_init(void);
void SYSCFG_DL_uart_gyro_init(void);
void SYSCFG_DL_uart_computer_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
