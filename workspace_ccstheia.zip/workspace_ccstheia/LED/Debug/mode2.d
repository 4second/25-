# FIXED

mode2.o: ../mode2.c ../mode2.h ../app_common.h ../delay.h ../hwt101.h \
 ../line_sensor.h ../motor.h
../mode2.h:
../app_common.h:
../delay.h:
../hwt101.h:
../line_sensor.h:
../motor.h:
