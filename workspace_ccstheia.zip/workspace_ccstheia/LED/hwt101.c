#include "hwt101.h"
#include "uart.h"

#define HWT101_FRAME_HEADER       ((uint8_t) 0x55U)
#define HWT101_FRAME_TYPE_ANGLE   ((uint8_t) 0x53U)
#define HWT101_FRAME_LENGTH       (11U)

static Hwt101Data hwt101Data;
static uint8_t hwt101Frame[HWT101_FRAME_LENGTH];
static uint8_t hwt101FrameIndex;

static int16_t hwt101_read_i16(uint8_t low, uint8_t high)
{
    return (int16_t) ((uint16_t) low | ((uint16_t) high << 8));
}

static int16_t hwt101_angle_to_cdeg(int16_t raw)
{
    return (int16_t) (((int32_t) raw * 18000L) / 32768L);
}

static bool hwt101_checksum_valid(void)
{
    uint8_t sum = 0;

    for (uint8_t i = 0; i < (HWT101_FRAME_LENGTH - 1U); i++) {
        sum = (uint8_t) (sum + hwt101Frame[i]);
    }

    return sum == hwt101Frame[HWT101_FRAME_LENGTH - 1U];
}

static void hwt101_process_frame(void)
{
    if ((hwt101Frame[1] != HWT101_FRAME_TYPE_ANGLE) || !hwt101_checksum_valid()) {
        return;
    }

    hwt101Data.roll_cdeg = hwt101_angle_to_cdeg(hwt101_read_i16(hwt101Frame[2], hwt101Frame[3]));
    hwt101Data.pitch_cdeg = hwt101_angle_to_cdeg(hwt101_read_i16(hwt101Frame[4], hwt101Frame[5]));
    hwt101Data.yaw_cdeg = hwt101_angle_to_cdeg(hwt101_read_i16(hwt101Frame[6], hwt101Frame[7]));
    hwt101Data.angle_valid = true;
}

void hwt101_init(void)
{
    hwt101Data.roll_cdeg = 0;
    hwt101Data.pitch_cdeg = 0;
    hwt101Data.yaw_cdeg = 0;
    hwt101Data.angle_valid = false;
    hwt101FrameIndex = 0;
}

void hwt101_update(void)
{
    uint8_t data;

    while (uart_gyro_receive_char_check(&data)) {
        if (hwt101FrameIndex == 0U) {
            if (data != HWT101_FRAME_HEADER) {
                continue;
            }
        }

        hwt101Frame[hwt101FrameIndex] = data;
        hwt101FrameIndex++;

        if (hwt101FrameIndex >= HWT101_FRAME_LENGTH) {
            hwt101_process_frame();
            hwt101FrameIndex = 0;
        }
    }
}

bool hwt101_get_data(Hwt101Data *data)
{
    if (!hwt101Data.angle_valid) {
        return false;
    }

    *data = hwt101Data;
    return true;
}

bool hwt101_get_yaw_cdeg(int16_t *yaw_cdeg)
{
    if (!hwt101Data.angle_valid) {
        return false;
    }

    *yaw_cdeg = hwt101Data.yaw_cdeg;
    return true;
}
