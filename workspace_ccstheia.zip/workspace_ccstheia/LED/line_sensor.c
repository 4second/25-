#include "line_sensor.h"
#include "delay.h"
#include "uart.h"

static bool line_sensor_read_byte_timeout(uint8_t *data, uint32_t timeoutMs)
{
    while (timeoutMs--) {
        if (uart_follow_receive_char_check(data)) {
            return true;
        }
        delay_ms(1);
    }

    return false;
}

bool line_sensor_read(uint8_t *data)
{
    uart_follow_send_char(LINE_SENSOR_REQUEST_CMD);
    return line_sensor_read_byte_timeout(data, LINE_SENSOR_TIMEOUT_MS);
}
