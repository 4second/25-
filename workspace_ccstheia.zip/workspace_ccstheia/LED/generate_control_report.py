from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from xml.sax.saxutils import escape

OUT = Path(r'C:/Users/ROG/Desktop/[控制题]浙江理工大学_智能循迹与视觉定位控制小车设计.docx')
TEMPLATE = OUT
TMP_OUT = OUT.with_name(OUT.stem + '_tmp.docx')
TITLE = '激光打靶小车（A题）'
SUBTITLE = '智能循迹与视觉伺服控制系统设计报告'
SCHOOL = '浙江理工大学'
SCHOOL_EN = 'Zhejiang Sci-Tech University'
W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
body = []

def run(text, bold=False, font='宋体', size=21):
    text = escape(text)
    b = '<w:b/>' if bold else ''
    return f'<w:r><w:rPr><w:rFonts w:ascii="{font}" w:hAnsi="{font}" w:eastAsia="{font}"/>{b}<w:sz w:val="{size}"/><w:szCs w:val="{size}"/></w:rPr><w:t xml:space="preserve">{text}</w:t></w:r>'

def p(text='', align=None, bold=False, font='宋体', size=21, indent=False):
    jc = f'<w:jc w:val="{align}"/>' if align else ''
    ind = '<w:ind w:firstLine="420"/>' if indent and text else ''
    spacing = '<w:spacing w:line="300" w:lineRule="auto"/>' if text else ''
    body.append(f'<w:p><w:pPr>{jc}{ind}{spacing}</w:pPr>{run(text, bold, font, size)}</w:p>')

def h(text, level=1):
    p(text, bold=True, font='黑体', size=32 if level == 1 else 28 if level == 2 else 24)

def page_break():
    body.append('<w:p><w:r><w:br w:type="page"/></w:r></w:p>')

def tbl(rows):
    xml = ['<w:tbl><w:tblPr><w:tblW w:w="0" w:type="auto"/><w:tblBorders><w:top w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:left w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:bottom w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:right w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:insideH w:val="single" w:sz="4" w:space="0" w:color="000000"/><w:insideV w:val="single" w:sz="4" w:space="0" w:color="000000"/></w:tblBorders></w:tblPr>']
    for row in rows:
        xml.append('<w:tr>')
        for cell in row:
            xml.append('<w:tc><w:tcPr><w:tcW w:w="0" w:type="auto"/></w:tcPr>')
            for line in str(cell).split('\n'):
                xml.append(f'<w:p><w:pPr><w:spacing w:line="300" w:lineRule="auto"/></w:pPr>{run(line)}</w:p>')
            xml.append('</w:tc>')
        xml.append('</w:tr>')
    xml.append('</w:tbl>')
    body.append(''.join(xml))

def placeholder(title, lines=6):
    tbl([[title + '\n' + '\n'.join([' ' for _ in range(lines)])]])

def code(text):
    for line in text.split('\n'):
        p(line, font='Consolas', size=18)

# Cover
for _ in range(3): p()
p(TITLE, align='center', bold=True, font='黑体', size=44)
p(SUBTITLE, align='center', bold=True, font='黑体', size=32)
p('', align='center')
p(SCHOOL, align='center', bold=True, font='黑体', size=36)
p(SCHOOL_EN, align='center', font='Times New Roman', size=28)
for _ in range(3): p()
tbl([['题目类别', '控制题'], ['题目名称', TITLE], ['学校', SCHOOL], ['参赛人员', '　　　　　　　　　　　　　　'], ['指导教师', '　　　　　　　　　　　　　　'], ['完成日期', '　　　　年　　　月　　　日']])
p('说明：本文档依据当前 MSPM0 小车控制工程和视觉伺服方案整理生成。视觉识别由上位机完成，本文重点描述小车底层控制、状态机实现和视觉伺服闭环思路。')
page_break()

p('目    录', align='center', bold=True, font='黑体', size=36)
for item in ['摘    要','1  方案论证','  1.1  题目任务理解','  1.2  系统总体方案','  1.3  循迹控制方案','  1.4  打靶视觉伺服方案','2  硬件系统设计','3  软件与状态机设计','4  视觉算法设计','5  测试与结果分析','结    论','附录A  主要接口与引脚分配','附录B  状态机与关键代码','附录C  视觉部分补充材料','附录D  实物与测试照片']:
    p(item)
page_break()

p('摘    要', align='center', bold=True, font='黑体', size=32)
p('本设计针对“激光打靶小车（A题）”要求，完成了一套以 MSPM0G3507 为底层控制核心、以视觉边缘计算模块为打靶识别核心的智能循迹与视觉伺服控制系统。系统在巡线阶段仅使用灰度循迹信息完成小车运动控制，并通过状态机实现起步对线、路口识别、定向转弯、断线跨越、回正稳定、终点停车等动作；在打靶阶段利用视觉模块识别靶心与激光光斑，通过车身角度调整完成闭环瞄准。', indent=True)
p('底层控制程序采用模块化结构，将电机驱动、循迹传感器、陀螺仪姿态、按键蜂鸣器和各题模式逻辑分离。循迹算法通过八路传感器加权误差判断黑线相对位置，根据偏差分级输出左右轮速度；转弯过程采用中心线丢失、重新捕获与稳定计数的组合判据，降低短暂全白、全黑或线条断裂造成的误判；断线区域结合 HWT101 航向角进行短时姿态保持。视觉伺服部分采用 ROCK 5C 运行 OpenCV 算法，完成激光点定位、靶心椭圆拟合、坐标滤波和死区判定，并为底盘控制提供水平偏差量。', indent=True)
p('关键词：激光打靶小车；MSPM0G3507；状态机；八路循迹；视觉伺服；OpenCV')
page_break()

h('1  方案论证', 1)
h('1.1  题目任务理解', 2)
p('题目要求制作一套简易激光打靶小车装置，包括自动寻迹小车和激光瞄准模块两部分。巡线与电机控制必须由 TI MSPM0 系列 MCU 完成，巡线阶段不得借助视觉模块；打靶阶段必须基于视觉反馈识别靶心偏差，并通过调整车身姿态使激光光斑稳定落在目标靶心附近。系统还需要具备动作连贯、过程稳定、到达目标后声光提示以及安全防护等特性。', indent=True)
h('1.2  系统总体方案', 2)
p('系统采用“底层运动控制 + 上位视觉伺服”的分层方案。底层由 MSPM0G3507 负责所有底盘运动，包括循迹、转弯、停车、蜂鸣器提示和各题模式调度；上位视觉部分由 ROCK 5C 负责图像采集与目标识别，仅在打靶阶段参与闭环瞄准。这样既满足巡线阶段传感器使用限制，又能在打靶阶段利用视觉反馈提高瞄准精度。', indent=True)
h('1.3  循迹控制方案', 2)
p('循迹控制不在报告中展开复述具体行驶路线，而是按状态机实现。程序把每一题拆分为若干有限状态，每个状态只处理一种明确动作，例如起步对线、检测路口、执行转弯、等待中心线重新出现、稳定回正、跨越断线和停车。状态切换条件由传感器图案、稳定计数、最小运行时间和陀螺仪航向共同决定，从而避免单点判断造成误动作。', indent=True)
h('1.4  打靶视觉伺服方案', 2)
p('打靶阶段采用视觉闭环方案。视觉端从摄像头图像中同时获取靶心位置和激光光斑位置，计算二者水平偏差；控制端根据偏差方向与大小驱动车身缓慢旋转，使激光点逐渐靠近靶心。当偏差进入设定死区并持续稳定后，认为打靶命中，并由蜂鸣器给出提示。第五、第六项发挥任务目前保留为视觉联调与连续打靶扩展方向，报告中预留测试数据与截图区域。', indent=True)

h('2  硬件系统设计', 1)
h('2.1  底层控制硬件', 2)
p('下位机采用 MSPM0G3507 微控制器，负责循迹、电机控制、蜂鸣器提示、按键启动以及姿态传感器数据处理。小车底盘使用双直流电机差速驱动，左右轮由两路 PWM 分别调速，方向引脚控制前进、后退和原地转向。停车函数采用主动刹车方式，使小车在路口等待和终点停车时具有较好的位置保持能力。', indent=True)
h('2.2  感知与执行机构', 2)
p('巡线阶段使用八路灰度循迹传感器识别黑色轨迹线。断线跨越和长直线保持阶段使用 HWT101 姿态传感器提供 yaw 角，辅助小车在暂时失去黑线参考时保持方向。人机交互部分由按键和蜂鸣器组成，按键用于模式启动或切换，蜂鸣器用于题目阶段提示、完成提示和命中提示。', indent=True)
h('2.3  视觉打靶硬件', 2)
p('视觉端采用 ROCK 5C 单板计算机与 USB 摄像头。摄像头工作在 640×480、30FPS 条件下，实时采集 A4 紫外感光靶纸和激光光斑图像。ROCK 5C 运行 OpenCV 视觉识别程序，完成靶心与激光点定位，并输出用于车身姿态调整的偏差结果。', indent=True)
h('2.4  主要引脚分配', 2)
tbl([['模块','功能','外设/信号','引脚'],['左电机','方向控制','ain1 / ain2','PA26 / PB24'],['右电机','方向控制','bin1 / bin2','PA17 / PA15'],['左电机 PWM','速度控制','pwmA / TIMG7 CCP1','PA24'],['右电机 PWM','速度控制','pwmB / TIMG8 CCP1','PA22'],['蜂鸣器','运行提示','GPIO','PA16'],['按键','模式切换','GPIO 输入上拉','PB21'],['循迹模块','灰度数据输入','uart_follow','PB13 / PB12'],['陀螺仪','姿态角输入','uart_gyro','PA1 / PA0'],['调试接口','SWD 下载调试','SWCLK / SWDIO','PA20 / PA19']])

h('3  软件与状态机设计', 1)
h('3.1  软件总体结构', 2)
p('工程采用分层和模块化结构。main 函数仅完成 SysConfig 初始化、电机初始化、姿态传感器初始化、视觉状态初始化和全局中断使能；app_sequence 负责按键等待、蜂鸣器提示和模式顺序调度；app_common 封装循迹误差、路口判断、转弯保持、断线恢复和按键蜂鸣器公共函数；mode1、mode2、mode3、mode4 分别实现各题状态机。', indent=True)
placeholder('图3.1 软件总体结构图预留区域', 6)
h('3.2  总调度状态机', 2)
tbl([['阶段','触发条件','执行动作','退出条件'],['等待启动','系统初始化完成','等待按键','按键确认后进入 mode1'],['mode1','蜂鸣器响 1 声','执行第一组基础状态机','状态机返回 DONE 或按键切换'],['mode2','蜂鸣器响 2 声','执行第二组基础状态机','状态机返回 DONE 或按键切换'],['mode3','蜂鸣器响 3 声','执行第三组长路线状态机','完成后等待进入视觉阶段'],['mode4','蜂鸣器响 4 声','执行视觉伺服对准控制','当前作为打靶扩展任务持续运行']])
h('3.3  mode1 状态机实现', 2)
p('mode1 的实现重点不是在程序中硬编码路线，而是把基础循迹过程拆成一组状态。每个状态只保存必要的计数器和上一次线偏向，并根据传感器图案完成转移。最终停车由终点区域黑色特征和末端全白特征共同判断，提高可靠性。', indent=True)
tbl([['状态','控制动作','主要转移条件'],['START_ALIGN_AB','起步后寻找并稳定压线','中心线稳定计数达到阈值'],['GO_FIRST_LINE','按加权误差循迹前进','右侧路口特征连续出现'],['PREPARE_FIRST_TURN','短暂停车，消除惯性','停车计数完成'],['TURN_TO_EDGE_8','按指定方向执行转弯','中心线丢失后重新捕获，或超时进入回正'],['ALIGN_AFTER_FIRST_TURN','低速回正并稳定压线','中心线稳定计数达到阈值'],['GO_TO_C','继续循迹并识别终点/断线特征','全白保持计数达到阈值'],['TURN_AROUND_AT_C','执行原地调头','重新检测到有效线或达到最大转向时间'],['ALIGN_AFTER_TURN_AROUND','调头后回正','中心线稳定'],['RETURN_TO_B','返程循迹并检测下一路口','左侧路口特征连续出现'],['PREPARE_SECOND_TURN','短暂停车','停车计数完成'],['TURN_TO_EDGE_1','执行第二次转弯','重新捕获中心线或超时进入回正'],['ALIGN_AFTER_SECOND_TURN','第二次转弯后回正','中心线稳定'],['RETURN_TO_A','返程终点判断','黑色终点或全白末端满足计数'],['STOPPED','主动刹车','返回完成结果']])
h('3.4  mode2 状态机实现', 2)
p('mode2 在基础循迹状态机上增加断线跨越逻辑。进入断线前记录当前 yaw 角作为目标方向，在缺少有效黑线参考时使用陀螺仪误差修正左右轮速度，重新检测到有效线后进入回正状态，再执行终点识别。', indent=True)
tbl([['状态','控制动作','主要转移条件'],['START_ALIGN_AB / GO_FIRST_LINE','起步对线与正常循迹','中心稳定、路口触发'],['TURN_TO_EDGE_8 / ALIGN_AFTER_FIRST_TURN','路口转弯与回正','中心线重新捕获并稳定'],['GO_TO_C','进入断线前循迹','全白持续达到断线判据'],['CROSS_GAP_GYRO','按 yaw 角保持方向跨越断线','重新检测到非全白/非全黑有效线'],['ALIGN_AFTER_REACQUIRE_D','断线后回正','中心稳定计数达到阈值'],['GO_TO_E','终点特征判断','中心与左侧分支特征持续出现'],['STOPPED','主动刹车','返回完成结果']])
h('3.5  mode3 状态机实现', 2)
p('mode3 采用单程状态机复用的方式实现长路线与返程控制。程序先执行一次 route_once，到达末端后调用独立调头函数，再执行第二次 route_once。为改善长路线转弯时的机械阻力问题，mode3 使用独立转弯速度参数，提高转弯力矩而不影响前两题。', indent=True)
tbl([['模块','作用','实现要点'],['mode3_run_route_once','单程状态机','包含起步对线、路口转弯、断线跨越、终点检测等状态'],['mode3_turn_around_between_runs','中间调头','固定方向转动，检测有效线后进入稳定回正'],['mode3_run','模式入口','route_once → turn_around → route_once'],['mode3_follow_corner','增强转弯力','使用 mode3 专用内外轮速度参数']])
h('3.6  mode4 视觉伺服状态机', 2)
p('mode4 面向打靶阶段。控制逻辑抽象为搜索、跟踪和命中保持三个状态：未获得目标时低速搜索；获得偏差后按偏差方向转动车身；偏差进入死区并稳定后停止并提示。当前工程已实现底盘侧视觉控制框架，第五、第六项发挥任务暂未完成完整联调，后续可在该状态机基础上加入命中保持计时、连续打靶计数和脱靶恢复。', indent=True)
tbl([['状态','输入条件','控制动作','转移条件'],['SEARCH','未检测到有效靶心/激光偏差','小车低速旋转搜索','视觉端输出有效偏差'],['TRACK','获得水平偏差 dx','根据 dx 方向和大小调整车身角度','abs(dx) 进入死区'],['HIT_HOLD','偏差处于死区','停车保持并蜂鸣提示','保持计时完成或目标丢失'],['RECOVER','目标短时丢失或偏差突变','降低速度重新搜索','重新获得稳定目标']])
placeholder('图3.2 各模式状态机流程图预留区域', 8)

h('4  视觉算法设计', 1)
h('4.1  视觉硬件架构', 2)
p('视觉部分采用主从机协同架构。ROCK 5C 单板计算机负责高帧率读取摄像头数据并运行 OpenCV 视觉算法；MSPM0G3507 负责底盘运动控制。USB 免驱摄像头以 640×480、30FPS 采集 A4 紫外感光靶纸及激光光斑图像，为闭环瞄准提供实时视觉反馈。', indent=True)
h('4.2  图像预处理与激光屏蔽', 2)
p('视觉程序首先将图像转换为灰度图，并利用全局最高亮度点定位激光光斑。为避免激光高光破坏靶心线条连续性，系统以激光点为圆心生成遮罩，并通过图像修复算法填补高光区域，使后续轮廓提取不受激光光晕干扰。', indent=True)
h('4.3  靶心特征提取', 2)
p('针对紫外感光纸上细线同心圆对比度低、相机视角存在倾斜的问题，视觉端不采用传统颜色阈值或标准圆检测，而采用高对比度几何椭圆拟合策略。程序通过 CLAHE 增强线条对比度，经高斯滤波、Canny 边缘检测和形态学膨胀获得闭合轮廓，再对尺寸和长宽比合规的轮廓进行椭圆拟合。由于倾斜同心圆在图像中呈同心椭圆，各椭圆中心的中位数可作为稳定靶心位置。', indent=True)
h('4.4  坐标滤波与稳定判定', 2)
p('靶心坐标与激光坐标均经过指数移动平均滤波，平滑系数取 α=0.3，以滤除高频抖动和单帧误检。系统启动后设置曝光稳定等待时间，并要求目标坐标与激光坐标连续稳定出现超过设定帧数后，才进入有效跟踪，避免刚启动时曝光变化和运动模糊导致误控制。', indent=True)
h('4.5  闭环控制与监控', 2)
p('视觉端计算靶心与激光点的水平像素偏差 dx。若 |dx| 大于死区阈值，则底盘按偏差方向调整车身角度；若 |dx| 小于等于 20 像素并持续稳定，则判定激光已对准靶心。视觉程序同时通过 Flask 在局域网内推送带有靶心、激光点和状态文字的实时画面，便于封箱部署后使用手机或电脑进行非接触式监控。', indent=True)
placeholder('视觉识别效果截图、靶心椭圆拟合截图、激光屏蔽前后对比图预留区域', 10)

h('5  测试与结果分析', 1)
h('5.1  测试条件', 2)
p('测试对象包括 MSPM0G3507 控制板、双电机小车底盘、八路灰度循迹模块、HWT101 姿态传感器、ROCK 5C 视觉端、USB 摄像头、蓝紫激光笔和 A4 紫外感光靶纸。测试前需检查电池电压、电机方向、传感器阈值、陀螺仪数据、摄像头曝光和激光安全防护。', indent=True)
h('5.2  功能测试记录', 2)
tbl([['测试项目','测试内容','现象记录','是否通过','备注'],['基础任务 1','状态机完成基础循迹、调头与停车','　　　　　　　　　','　　　','　　　'],['基础任务 2','状态机完成断线跨越与终点停车','　　　　　　　　　','　　　','　　　'],['基础任务 3','长路线状态机与中间调头','　　　　　　　　　','　　　','　　　'],['打靶任务 1','F 点视觉搜索、对准与保持','　　　　　　　　　','　　　','待完整联调'],['打靶任务 2','EF 段任意点对准','　　　　　　　　　','　　　','暂未完成'],['连续打靶','基础路线后连续视觉打靶','　　　　　　　　　','　　　','暂未完成'],['稳定性','短暂全白/全黑、转弯丢线恢复','　　　　　　　　　','　　　','　　　']])
h('5.3  结果分析', 2)
p('目前底层循迹部分已形成较完整的状态机框架，能够针对路口、断线、调头和终点停车分别设置独立判据，减少相互干扰。视觉部分已明确采用靶心椭圆拟合、激光屏蔽、坐标滤波和死区控制的闭环方案。第五、第六项发挥任务仍需结合实际视觉端输出和场地光照完成联调，后续重点是补充命中保持计时、连续打靶失败恢复以及实测数据。', indent=True)
placeholder('实车运行照片、测试数据、命中痕迹照片预留区域', 10)

h('结    论', 1)
p('本设计完成了激光打靶小车的底层控制系统和视觉伺服方案设计。底层控制以 MSPM0G3507 为核心，采用模块化状态机实现循迹、转弯、断线跨越、调头、停车和模式切换；视觉部分以 ROCK 5C 和 OpenCV 为核心，采用激光屏蔽、椭圆拟合、中值抗噪、低通滤波和死区控制实现靶心对准。该方案满足题目对巡线阶段传感器使用限制和打靶阶段视觉闭环控制的基本要求，并为后续第五、第六项发挥任务预留了扩展空间。', indent=True)

h('附录A  主要接口与引脚分配', 1)
tbl([['功能','信号名','引脚'],['左电机方向','ain1 / ain2','PA26 / PB24'],['右电机方向','bin1 / bin2','PA17 / PA15'],['左电机 PWM','pwmA','PA24'],['右电机 PWM','pwmB','PA22'],['蜂鸣器','buzzer','PA16'],['按键','key','PB21'],['循迹模块','uart_follow','PB13 / PB12'],['陀螺仪','uart_gyro','PA1 / PA0']])
h('附录B  状态机与关键代码', 1)
p('主函数保持短小，仅负责初始化与应用调度：')
code('#include "app_sequence.h"\n#include "hwt101.h"\n#include "motor.h"\n#include "ti_msp_dl_config.h"\n#include "vision_uart.h"\n\nint main(void)\n{\n    SYSCFG_DL_init();\n    motors_init();\n    hwt101_init();\n    vision_uart_init();\n    __enable_irq();\n\n    while (1) {\n        app_run_all_modes();\n    }\n}')
tbl([['文件','作用'],['empty.c','系统初始化和主循环'],['app_sequence.c','模式调度、按键等待与蜂鸣器提示'],['app_common.c / app_common.h','循迹判断、转向、断线恢复和公共函数'],['mode1.c','基础任务 1 状态机'],['mode2.c','基础任务 2 状态机'],['mode3.c','基础任务 3 状态机'],['mode4.c','视觉伺服底盘控制'],['motor.c','左右电机方向和 PWM 控制'],['line_sensor.c','八路循迹传感器读取'],['hwt101.c','姿态传感器帧解析']])
h('附录C  视觉部分补充材料', 1)
placeholder('ROCK 5C 视觉程序流程图预留区域', 8)
placeholder('OpenCV 靶心检测、激光点检测、Flask 监控界面截图预留区域', 10)
h('附录D  实物与测试照片', 1)
placeholder('整车实物照片预留区域', 8)
placeholder('底盘、电机、循迹传感器、激光器、摄像头安装照片预留区域', 8)
placeholder('赛道运行与打靶测试照片预留区域', 8)

sect = '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1417" w:right="1474" w:bottom="1417" w:left="1474" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr>'
document_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' + f'<w:document xmlns:w="{W_NS}" xmlns:r="{R_NS}"><w:body>' + ''.join(body) + sect + '</w:body></w:document>'
with ZipFile(TEMPLATE, 'r') as zin, ZipFile(TMP_OUT, 'w', ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        if item.filename == 'word/document.xml':
            zout.writestr(item, document_xml.encode('utf-8'))
        else:
            zout.writestr(item, zin.read(item.filename))
TMP_OUT.replace(OUT)
print(OUT)
