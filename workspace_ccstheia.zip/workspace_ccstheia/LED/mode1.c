#include "mode1.h"

#include "app_common.h"
#include "delay.h"
#include "hwt101.h"
#include "line_sensor.h"
#include "motor.h"

typedef enum {
    CAR_STATE_START_ALIGN_AB,
    CAR_STATE_GO_FIRST_LINE,
    CAR_STATE_PREPARE_FIRST_TURN,
    CAR_STATE_TURN_TO_EDGE_8,
    CAR_STATE_ALIGN_AFTER_FIRST_TURN,
    CAR_STATE_GO_TO_C,
    CAR_STATE_TURN_AROUND_AT_C,
    CAR_STATE_ALIGN_AFTER_TURN_AROUND,
    CAR_STATE_RETURN_TO_B,
    CAR_STATE_PREPARE_SECOND_TURN,
    CAR_STATE_TURN_TO_EDGE_1,
    CAR_STATE_ALIGN_AFTER_SECOND_TURN,
    CAR_STATE_RETURN_TO_A,
    CAR_STATE_STOPPED
} CarState;

ModeResult mode1_run(void)
{
    uint8_t lineSensorData = LINE_SENSOR_ALL_WHITE_DATA;
    uint16_t stateLoopCount = 0;
    uint16_t whiteLoopCount = 0;
    uint8_t rightCornerDetectCount = 0;
    uint8_t leftCornerDetectCount = 0;
    uint8_t centerStableCount = 0;
    uint8_t blackCircleLoopCount = 0;
    uint8_t routeTurnCount = 0;
    int16_t currentYaw = 0;
    int16_t straightTargetYaw = 0;
    bool gyroValid = false;
    bool straightYawCaptured = false;
    bool lineRead = false;
    bool turnCenterLost = false;
    CarState carState = CAR_STATE_START_ALIGN_AB;
    LineSide lastLineSide = LINE_SIDE_RIGHT;

    while (1) {
        hwt101_update();
        gyroValid = hwt101_get_yaw_cdeg(&currentYaw);

        if (app_button_pressed()) {
            motors_stop();
            (void) app_button_take_press();
            return MODE_RESULT_SWITCH_TO_MODE2;
        }

        if (carState == CAR_STATE_STOPPED) {
            motors_stop();
            return MODE_RESULT_DONE;
        }

        lineRead = line_sensor_read(&lineSensorData);
        if (!lineRead) {
            if (carState == CAR_STATE_TURN_TO_EDGE_8) {
                stateLoopCount++;
                car_follow_corner(CORNER_STATE_RIGHT);
                lastLineSide = LINE_SIDE_RIGHT;
                if (stateLoopCount >= LINE_SENSOR_CORNER_MAX_COUNT) {
                    carState = CAR_STATE_ALIGN_AFTER_FIRST_TURN;
                    stateLoopCount = 0;
                    centerStableCount = 0;
                    whiteLoopCount = 0;
                }
            } else if (carState == CAR_STATE_TURN_AROUND_AT_C) {
                stateLoopCount++;
                motors_turn_right_speed(MOTOR_TURN_SPEED, MOTOR_TURN_SPEED);
                lastLineSide = LINE_SIDE_LEFT;
                if (stateLoopCount >= LINE_SENSOR_TURN_AROUND_MAX_COUNT) {
                    carState = CAR_STATE_ALIGN_AFTER_TURN_AROUND;
                    stateLoopCount = 0;
                    centerStableCount = 0;
                    whiteLoopCount = 0;
                }
            } else if (carState == CAR_STATE_TURN_TO_EDGE_1) {
                stateLoopCount++;
                car_follow_corner(CORNER_STATE_LEFT);
                lastLineSide = LINE_SIDE_LEFT;
                if (stateLoopCount >= LINE_SENSOR_CORNER_MAX_COUNT) {
                    carState = CAR_STATE_ALIGN_AFTER_SECOND_TURN;
                    stateLoopCount = 0;
                    centerStableCount = 0;
                    whiteLoopCount = 0;
                    routeTurnCount = 2U;
                    lastLineSide = LINE_SIDE_LEFT;
                    straightYawCaptured = false;
                }
            } else {
                motors_stop();
            }
            delay_ms(5);
            continue;
        }

        switch (carState) {
        case CAR_STATE_START_ALIGN_AB:
            stateLoopCount++;
            if (lineSensorData == LINE_SENSOR_ALL_WHITE_DATA) {
                centerStableCount = 0;
                car_follow_transient_white(lastLineSide);
            } else {
                car_follow_line_stable(lineSensorData, &lastLineSide);
                if (line_sensor_reacquired_center(lineSensorData)) {
                    centerStableCount++;
                } else {
                    centerStableCount = 0;
                }
            }

            if (centerStableCount >= LINE_SENSOR_STABLE_CENTER_COUNT) {
                carState = CAR_STATE_GO_FIRST_LINE;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                rightCornerDetectCount = 0;
                straightYawCaptured = false;
            }
            break;

        case CAR_STATE_GO_FIRST_LINE:
            stateLoopCount++;
            if ((stateLoopCount >= LINE_SENSOR_START_TURN_MIN_COUNT) &&
                line_sensor_detect_right_corner(lineSensorData)) {
                rightCornerDetectCount++;
            } else {
                rightCornerDetectCount = 0;
            }

            if (rightCornerDetectCount >= LINE_SENSOR_CORNER_TRIGGER_COUNT) {
                carState = CAR_STATE_PREPARE_FIRST_TURN;
                stateLoopCount = 0;
                rightCornerDetectCount = 0;
                whiteLoopCount = 0;
                centerStableCount = 0;
                straightYawCaptured = false;
                motors_stop();
            } else {
                if (lineSensorData != LINE_SENSOR_ALL_WHITE_DATA) {
                    car_follow_line_stable(lineSensorData, &lastLineSide);
                } else {
                    car_follow_transient_white(lastLineSide);
                }
            }
            break;

        case CAR_STATE_PREPARE_FIRST_TURN:
            stateLoopCount++;
            motors_stop();

            if (stateLoopCount >= LINE_SENSOR_BRANCH_STOP_COUNT) {
                carState = CAR_STATE_TURN_TO_EDGE_8;
                stateLoopCount = 0;
                centerStableCount = 0;
                turnCenterLost = false;
                lastLineSide = LINE_SIDE_RIGHT;
            }
            break;

        case CAR_STATE_TURN_TO_EDGE_8:
            stateLoopCount++;
            car_follow_corner(CORNER_STATE_RIGHT);
            lastLineSide = LINE_SIDE_RIGHT;

            if ((stateLoopCount >= LINE_SENSOR_TURN_LOST_MIN_COUNT) &&
                !line_sensor_centered(lineSensorData)) {
                turnCenterLost = true;
            }

            if (!turnCenterLost || (stateLoopCount < LINE_SENSOR_CORNER_MIN_COUNT)) {
                centerStableCount = 0;
            } else if (line_sensor_reacquired_center(lineSensorData)) {
                centerStableCount++;
            } else {
                centerStableCount = 0;
            }

            if (centerStableCount >= LINE_SENSOR_CORNER_CENTER_COUNT) {
                carState = CAR_STATE_ALIGN_AFTER_FIRST_TURN;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                routeTurnCount = 1U;
                lastLineSide = LINE_SIDE_RIGHT;
                straightYawCaptured = false;
            } else if (stateLoopCount >= LINE_SENSOR_CORNER_MAX_COUNT) {
                carState = CAR_STATE_ALIGN_AFTER_FIRST_TURN;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
            }
            break;

        case CAR_STATE_ALIGN_AFTER_FIRST_TURN:
            stateLoopCount++;
            if (line_sensor_all_white_or_black(lineSensorData)) {
                whiteLoopCount++;
                centerStableCount = 0;
                car_hold_turn_direction(LINE_SIDE_RIGHT);
                if (whiteLoopCount <= LINE_SENSOR_TRANSIENT_INVALID_HOLD_COUNT) {
                    delay_ms(2U);
                }
            } else if (!line_sensor_centered(lineSensorData)) {
                whiteLoopCount = 0;
                centerStableCount = 0;
                car_turn_to_center_line(lineSensorData, LINE_SIDE_RIGHT);
            } else {
                whiteLoopCount = 0;
                centerStableCount++;
                car_follow_line_stable(lineSensorData, &lastLineSide);
            }

            if ((stateLoopCount >= LINE_SENSOR_STABLE_COUNT) &&
                (centerStableCount >= LINE_SENSOR_STABLE_CENTER_COUNT)) {
                carState = CAR_STATE_GO_TO_C;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                straightYawCaptured = false;
            }
            break;

        case CAR_STATE_GO_TO_C:
            stateLoopCount++;
            if (lineSensorData == LINE_SENSOR_ALL_WHITE_DATA) {
                if (stateLoopCount >= LINE_SENSOR_C_MIN_LOOP_COUNT) {
                    whiteLoopCount++;
                    car_follow_transient_white(lastLineSide);
                    if (whiteLoopCount >= LINE_SENSOR_WHITE_STOP_COUNT) {
                        carState = CAR_STATE_TURN_AROUND_AT_C;
                        stateLoopCount = 0;
                        centerStableCount = 0;
                        whiteLoopCount = 0;
                        straightYawCaptured = false;
                    }
                } else {
                    whiteLoopCount = 0;
                    car_follow_transient_white(lastLineSide);
                }
            } else {
                whiteLoopCount = 0;
                if (!line_sensor_centered(lineSensorData)) {
                    car_center_line_on_45(lineSensorData, &lastLineSide);
                } else {
                    car_follow_line_stable(lineSensorData, &lastLineSide);
                }
            }
            break;

        case CAR_STATE_TURN_AROUND_AT_C:
            stateLoopCount++;
            motors_turn_right_speed(MOTOR_TURN_SPEED, MOTOR_TURN_SPEED);
            lastLineSide = LINE_SIDE_LEFT;

            if ((stateLoopCount >= LINE_SENSOR_TURN_AROUND_MIN_COUNT) &&
                (lineSensorData != LINE_SENSOR_ALL_WHITE_DATA) &&
                (lineSensorData != LINE_SENSOR_ALL_BLACK_DATA)) {
                carState = CAR_STATE_ALIGN_AFTER_TURN_AROUND;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                straightYawCaptured = false;
            } else if (stateLoopCount >= LINE_SENSOR_TURN_AROUND_MAX_COUNT) {
                carState = CAR_STATE_ALIGN_AFTER_TURN_AROUND;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
            }
            break;

        case CAR_STATE_ALIGN_AFTER_TURN_AROUND:
            stateLoopCount++;
            if (!line_sensor_centered(lineSensorData)) {
                centerStableCount = 0;
                car_turn_to_center_line(lineSensorData, LINE_SIDE_RIGHT);
            } else {
                centerStableCount++;
                car_follow_line_stable(lineSensorData, &lastLineSide);
            }

            if ((stateLoopCount >= LINE_SENSOR_STABLE_COUNT) &&
                (centerStableCount >= LINE_SENSOR_STABLE_CENTER_COUNT)) {
                carState = CAR_STATE_RETURN_TO_B;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                leftCornerDetectCount = 0;
                straightYawCaptured = false;
            }
            break;

        case CAR_STATE_RETURN_TO_B:
            stateLoopCount++;
            if ((stateLoopCount >= LINE_SENSOR_RETURN_CORNER_MIN_COUNT) &&
                line_sensor_detect_left_corner(lineSensorData)) {
                leftCornerDetectCount++;
            } else {
                leftCornerDetectCount = 0;
            }

            if (leftCornerDetectCount >= LINE_SENSOR_CORNER_TRIGGER_COUNT) {
                carState = CAR_STATE_PREPARE_SECOND_TURN;
                stateLoopCount = 0;
                leftCornerDetectCount = 0;
                whiteLoopCount = 0;
                centerStableCount = 0;
                straightYawCaptured = false;
                motors_stop();
            } else {
                if (lineSensorData != LINE_SENSOR_ALL_WHITE_DATA) {
                    car_follow_line_stable(lineSensorData, &lastLineSide);
                } else {
                    car_follow_transient_white(lastLineSide);
                }
            }
            break;

        case CAR_STATE_PREPARE_SECOND_TURN:
            stateLoopCount++;
            motors_stop();

            if (stateLoopCount >= LINE_SENSOR_BRANCH_STOP_COUNT) {
                carState = CAR_STATE_TURN_TO_EDGE_1;
                stateLoopCount = 0;
                centerStableCount = 0;
                turnCenterLost = false;
                lastLineSide = LINE_SIDE_LEFT;
            }
            break;

        case CAR_STATE_TURN_TO_EDGE_1:
            stateLoopCount++;
            car_follow_corner(CORNER_STATE_LEFT);
            lastLineSide = LINE_SIDE_LEFT;

            if ((stateLoopCount >= LINE_SENSOR_TURN_LOST_MIN_COUNT) &&
                !line_sensor_centered(lineSensorData)) {
                turnCenterLost = true;
            }

            if (!turnCenterLost || (stateLoopCount < LINE_SENSOR_CORNER_MIN_COUNT)) {
                centerStableCount = 0;
            } else if (line_sensor_reacquired_center(lineSensorData)) {
                centerStableCount++;
            } else {
                centerStableCount = 0;
            }

            if (centerStableCount >= LINE_SENSOR_CORNER_CENTER_COUNT) {
                carState = CAR_STATE_ALIGN_AFTER_SECOND_TURN;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                routeTurnCount = 2U;
                lastLineSide = LINE_SIDE_LEFT;
                straightYawCaptured = false;
            } else if (stateLoopCount >= LINE_SENSOR_CORNER_MAX_COUNT) {
                carState = CAR_STATE_ALIGN_AFTER_SECOND_TURN;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                routeTurnCount = 2U;
                lastLineSide = LINE_SIDE_LEFT;
                straightYawCaptured = false;
            }
            break;

        case CAR_STATE_ALIGN_AFTER_SECOND_TURN:
            stateLoopCount++;
            if (!line_sensor_centered(lineSensorData)) {
                centerStableCount = 0;
                car_turn_to_center_line(lineSensorData, LINE_SIDE_LEFT);
            } else {
                centerStableCount++;
                car_follow_line_stable(lineSensorData, &lastLineSide);
            }

            if ((stateLoopCount >= LINE_SENSOR_STABLE_COUNT) &&
                (centerStableCount >= LINE_SENSOR_STABLE_CENTER_COUNT)) {
                carState = CAR_STATE_RETURN_TO_A;
                stateLoopCount = 0;
                centerStableCount = 0;
                whiteLoopCount = 0;
                blackCircleLoopCount = 0;
                straightYawCaptured = false;
            }
            break;

        case CAR_STATE_RETURN_TO_A:
            stateLoopCount++;
            if ((routeTurnCount >= 2U) &&
                (stateLoopCount >= LINE_SENSOR_A_MIN_LOOP_COUNT) &&
                (line_sensor_count_black(lineSensorData) >= LINE_SENSOR_A_BLACK_MIN_COUNT)) {
                blackCircleLoopCount++;
                if (blackCircleLoopCount >= LINE_SENSOR_A_STOP_COUNT) {
                    carState = CAR_STATE_STOPPED;
                    motors_stop();
                }
            } else {
                blackCircleLoopCount = 0;
            }

            if (carState != CAR_STATE_STOPPED) {
                if (lineSensorData == LINE_SENSOR_ALL_WHITE_DATA) {
                    whiteLoopCount++;
                    if ((routeTurnCount >= 2U) &&
                        (stateLoopCount >= LINE_SENSOR_A_MIN_LOOP_COUNT) &&
                        (whiteLoopCount >= LINE_SENSOR_FINAL_WHITE_STOP_COUNT)) {
                        carState = CAR_STATE_STOPPED;
                        motors_stop();
                    } else {
                        car_follow_transient_white(lastLineSide);
                    }
                } else {
                    whiteLoopCount = 0;
                    car_follow_line_stable(lineSensorData, &lastLineSide);
                }
            }
            break;

        case CAR_STATE_STOPPED:
        default:
            carState = CAR_STATE_STOPPED;
            motors_stop();
            break;
        }

        delay_ms(5);
    }
}

