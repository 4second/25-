#ifndef VISION_UART_H
#define VISION_UART_H

#include <stdbool.h>
#include <stdint.h>

/* ---- volatile 全局状态变量（中断中写入，主循环中读取）---- */
extern volatile int16_t  target_dx;
extern volatile uint8_t  target_found;

/* ---- 供 main.c 调用的初始化 ---- */
void vision_uart_init(void);

#endif
