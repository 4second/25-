#ifndef MODE4_H
#define MODE4_H

void mode4_run(void);

#endif
