#ifndef APP_SEQUENCE_H
#define APP_SEQUENCE_H

void app_run_all_modes(void);

#endif
