#include "mode4.h"

#include "delay.h"
#include "motor.h"
#include "ti_msp_dl_config.h"
#include "vision_uart.h"

static int16_t vision_filter(int16_t rawDx)
{
    static int16_t window[5] = {0};
    static uint8_t idx = 0;
    int16_t sorted[5];
    int16_t tmp;

    window[idx] = rawDx;
    idx = (idx + 1) % 5;

    for (uint8_t i = 0; i < 5; i++) {
        sorted[i] = window[i];
    }

    for (uint8_t i = 0; i < 4; i++) {
        for (uint8_t j = 0; j < 4 - i; j++) {
            if (sorted[j] > sorted[j + 1]) {
                tmp = sorted[j];
                sorted[j] = sorted[j + 1];
                sorted[j + 1] = tmp;
            }
        }
    }

    return (int16_t) ((sorted[1] + sorted[2] + sorted[3]) / 3);
}

void mode4_run(void)
{
    static int16_t lastError = 0;

    vision_uart_init();
    DL_UART_Main_enableInterrupt(uart_computer_INST, DL_UART_MAIN_INTERRUPT_RX);
    NVIC_EnableIRQ(uart_computer_INST_INT_IRQN);

    while (1) {
        if (target_found == 1U) {
            int16_t dx = vision_filter(target_dx);

            if ((dx > -20) && (dx < 20)) {
                motors_stop();
                lastError = 0;
            } else {
                int16_t dError = (int16_t) (dx - lastError);
                int16_t power;

                lastError = dx;
                power = (int16_t) ((2 * (dx > 0 ? dx : -dx) + 5 * dError) / 10);

                if (power < 10) {
                    power = 10;
                }
                if (power > 60) {
                    power = 60;
                }

                if (dx > 0) {
                    motors_turn_right_speed((uint8_t) power, (uint8_t) power);
                } else {
                    motors_turn_left_speed((uint8_t) power, (uint8_t) power);
                }
            }
        } else {
            motors_turn_right_speed(10U, 10U);
            lastError = 0;
        }
        delay_ms(50U);
    }
}
